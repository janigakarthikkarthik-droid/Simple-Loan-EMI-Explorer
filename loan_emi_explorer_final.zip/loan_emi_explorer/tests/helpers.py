"""Shared test helpers: isolated temp stores so tests never touch the real data folder."""
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from emi.storage import LoanStore  # noqa: E402


def temp_dir() -> Path:
    return Path(tempfile.mkdtemp(prefix="emi_test_"))


def temp_store(seed: bool = True) -> tuple[LoanStore, Path]:
    folder = temp_dir()
    if seed:
        shutil.copy(ROOT / "data" / "sample_loans.json", folder / "loans.json")
    store = LoanStore(folder / "loans.json", folder / "loans.csv", folder / "audit_log.txt")
    store.load()
    return store, folder


def valid_raw(**overrides) -> dict:
    raw = {"borrower": "Test Person", "loan_type": "Home", "principal": "1000000", "annual_rate": "8.5",
           "tenure_months": "240", "monthly_income": "150000", "start_date": "2026-01-15", "status": "Active", "notes": "unit test"}
    raw.update(overrides)
    return raw
