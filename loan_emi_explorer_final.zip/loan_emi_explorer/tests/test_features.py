import csv
import io
import unittest
from datetime import date

from tests.helpers import ROOT, temp_dir, temp_store, valid_raw

from emi import alerts as alerts_mod, config, export, importer, search, summary


class SearchTests(unittest.TestCase):
    def setUp(self):
        self.store, _ = temp_store()
        self.records = self.store.records

    def test_dataset_size_and_variety(self):
        self.assertGreaterEqual(len(self.records), 30)
        self.assertLessEqual(len(self.records), 50)
        self.assertEqual({r.loan_type for r in self.records}, set(config.LOAN_TYPES))
        self.assertEqual({r.status for r in self.records}, set(config.STATUSES))

    def test_keyword_is_case_insensitive_and_and_based(self):
        self.assertTrue(all("home" in f"{r.loan_type} {r.borrower} {r.notes}".lower() for r in search.search_records(self.records, "HOME")))
        both = search.search_records(self.records, "ravi duplicate")
        self.assertEqual(len(both), 2)
        self.assertEqual(search.search_records(self.records, "ravi nonexistentword"), [])

    def test_category_filters(self):
        cars = search.search_records(self.records, loan_types=["Car"])
        self.assertTrue(cars and all(r.loan_type == "Car" for r in cars))
        overdue = search.search_records(self.records, statuses=["Overdue"])
        self.assertTrue(overdue and all(r.status == "Overdue" for r in overdue))
        ranged = search.search_records(self.records, min_emi=10_000, max_emi=20_000)
        self.assertTrue(all(10_000 <= r.emi <= 20_000 for r in ranged))

    def test_sorting(self):
        by_emi = search.search_records(self.records, sort_by="emi", descending=True)
        self.assertEqual([r.emi for r in by_emi], sorted((r.emi for r in self.records), reverse=True))


class AlertTests(unittest.TestCase):
    def setUp(self):
        self.store, _ = temp_store()

    def codes(self, **filters):
        return {a.code for a in alerts_mod.generate_alerts(self.store.records, today=date(2026, 11, 22))}

    def test_every_rule_fires_on_the_sample_data(self):
        expected = {"OVERDUE", "PAST_MATURITY", "ENDING_SOON", "EMI_INCOME", "HIGH_RATE", "LONG_TENURE", "OUTLIER", "DUPLICATE"}
        self.assertTrue(expected <= self.codes(), expected - self.codes())

    def test_critical_sorted_first(self):
        levels = [a.level for a in alerts_mod.generate_alerts(self.store.records)]
        self.assertEqual(levels, sorted(levels, key=alerts_mod.LEVEL_ORDER.get))

    def test_clean_record_has_no_alerts(self):
        store, _ = temp_store(seed=False)
        store.add_record(valid_raw(monthly_income="500000", tenure_months="60", annual_rate="9", start_date="2026-06-01"))
        self.assertEqual(alerts_mod.generate_alerts(store.records, today=date(2026, 11, 22)), [])

    def test_emi_income_thresholds(self):
        store, _ = temp_store(seed=False)
        store.add_record(valid_raw(principal="1000000", tenure_months="60", annual_rate="9", monthly_income="30000", start_date="2026-06-01"))
        found = alerts_mod.generate_alerts(store.records, today=date(2026, 11, 22))
        self.assertEqual([a.level for a in found if a.code == "EMI_INCOME"], ["critical"])


class SummaryTests(unittest.TestCase):
    def test_totals_match_records(self):
        store, _ = temp_store()
        s = summary.compute_summary(store.records, today=date(2026, 11, 22))
        self.assertEqual(s["count"], len(store.records))
        self.assertAlmostEqual(s["total_principal"], sum(r.principal for r in store.records), places=1)
        self.assertAlmostEqual(s["total_interest"], sum(r.total_interest for r in store.records), places=1)
        self.assertEqual(sum(d["count"] for d in s["by_type"]), s["count"])
        self.assertEqual(sum(d["count"] for d in s["by_status"]), s["count"])
        self.assertEqual(sum(d["count"] for d in s["trend"]), s["count"])
        self.assertTrue(s["insights"])

    def test_empty_portfolio_is_safe(self):
        s = summary.compute_summary([])
        self.assertEqual(s["count"], 0)
        self.assertEqual(s["health"]["label"], "No data")


class ImporterTests(unittest.TestCase):
    def test_legacy_sample_file(self):
        result = importer.import_csv_file(ROOT / "data" / "legacy_loans_import.csv", [])
        self.assertEqual(len(result.valid), 8)
        self.assertEqual(len(result.errors), 11)
        messages = " ".join(m for e in result.errors for m in e.messages).lower()
        for needle in ["negative", "between 0% and 40%", "tenure is required", "number", "between 1 and 360", "loan type", "borrower name is required",
                       "formula", "real date", "too many columns", "duplicate"]:
            self.assertIn(needle, messages)
        self.assertIn("Row 10", importer.error_log_text(result))

    def test_import_into_store_assigns_ids(self):
        store, _ = temp_store(seed=False)
        result = importer.import_csv_file(ROOT / "data" / "legacy_loans_import.csv", store.records)
        added = store.add_many(result.valid)
        self.assertEqual([r.id for r in added], list(range(1, 9)))
        self.assertEqual(store.records[1].principal, 750000.0)               # "7.5 lakh"

    def test_reimport_flags_duplicates_of_existing_records(self):
        store, _ = temp_store(seed=False)
        store.add_many(importer.import_csv_file(ROOT / "data" / "legacy_loans_import.csv", []).valid)
        again = importer.import_csv_file(ROOT / "data" / "legacy_loans_import.csv", store.records)
        self.assertEqual(len(again.valid), 0)

    def test_format_errors(self):
        for text in ["", "a,b,c\n1,2,3\n"]:
            with self.assertRaises(importer.ImportFormatError):
                importer.parse_csv_text(text)
        with self.assertRaises(importer.ImportFormatError):
            importer.import_csv_file(ROOT / "no_such_file.csv")

    def test_tenure_years_and_semicolons(self):
        text = "name;type;amount;rate;tenure_years\nAsha Verma;Car;5 lakh;9;3\n"
        result = importer.parse_csv_text(text)
        self.assertEqual(len(result.valid), 1)
        self.assertEqual(result.valid[0]["tenure_months"], "3y")

    def test_template_round_trips(self):
        self.assertEqual(len(importer.parse_csv_text(importer.template_csv()).valid), 1)


class ExportTests(unittest.TestCase):
    def setUp(self):
        self.store, _ = temp_store()

    def test_markdown_contains_all_sections(self):
        md = export.markdown_report(self.store.records)
        for heading in ["# ", "## Headline numbers", "## Key insights", "## By loan type", "## By status", "## Monthly trend", "## Warnings", "## All records"]:
            self.assertIn(heading, md)

    def test_audit_and_csv(self):
        audit = export.audit_report(self.store.records, self.store.audit_path)
        self.assertIn("THRESHOLD WARNINGS", audit); self.assertIn("RECORD LEDGER", audit)
        rows = list(csv.DictReader(io.StringIO(export.csv_report(self.store.records))))
        self.assertEqual(len(rows), len(self.store.records))
        self.assertIn("warning_flags", rows[0])
        self.assertTrue(any(r["warning_flags"] for r in rows))

    def test_files_written(self):
        folder = temp_dir()
        paths = export.export_all(self.store.records, folder, self.store.audit_path)
        self.assertGreaterEqual(len(paths), 3)
        self.assertTrue(all(p.exists() and p.stat().st_size > 0 for p in paths))


class ChartTests(unittest.TestCase):
    def test_all_charts_render_including_empty(self):
        try:
            from emi import charts
        except ImportError:
            self.skipTest("matplotlib not installed")
        store, _ = temp_store()
        folder = temp_dir()
        for records in (store.records, store.records[:1], []):
            for name in charts.CHART_DRAWERS:
                self.assertGreater(len(charts.figure_bytes(charts.chart(name, records))), 1000)
            self.assertGreater(len(charts.figure_bytes(charts.dashboard(records))), 1000)
        path = charts.save_figure(charts.record_balance_chart(store.records[0]), folder / "x.png")
        self.assertTrue(path.read_bytes().startswith(b"\x89PNG"))


if __name__ == "__main__":
    unittest.main()
