import json
import unittest
from datetime import date

from tests.helpers import temp_store, valid_raw

from emi import config
from emi.calculator import amortization_schedule, calculate_emi, total_interest
from emi.ui_helpers import format_inr, short_inr
from emi.validation import (ValidationError, build_record, parse_amount, parse_choice, parse_date, parse_rate,
                            parse_tenure, parse_text)


class CalculatorTests(unittest.TestCase):
    def test_known_emi_values(self):
        self.assertEqual(calculate_emi(1_000_000, 8.5, 240), 8678.23)
        self.assertEqual(calculate_emi(500_000, 10, 60), 10623.52)

    def test_zero_rate_is_simple_division(self):
        self.assertEqual(calculate_emi(120_000, 0, 24), 5000.0)
        self.assertEqual(total_interest(120_000, 0, 24), 0.0)

    def test_boundaries(self):
        self.assertEqual(calculate_emi(1000, 0, 1), 1000.0)
        self.assertGreater(calculate_emi(config.MAX_PRINCIPAL, config.MAX_RATE, config.MAX_TENURE), 0)

    def test_invalid_arguments_raise(self):
        for args in [(0, 5, 12), (1000, 5, 0), (1000, -1, 12)]:
            with self.assertRaises(ValueError):
                calculate_emi(*args)

    def test_schedule_closes_to_zero_and_sums(self):
        for principal, rate, months in [(1_000_000, 8.5, 240), (25_000, 40, 12), (120_000, 0, 24), (1000, 0, 1)]:
            rows = amortization_schedule(principal, rate, months)
            self.assertEqual(len(rows), months)
            self.assertEqual(rows[-1]["balance"], 0.0)
            self.assertAlmostEqual(sum(r["principal_paid"] for r in rows), principal, places=1)


class ValidationTests(unittest.TestCase):
    def test_amount_formats(self):
        self.assertEqual(parse_amount("5 lakh"), 500000)
        self.assertEqual(parse_amount("₹2,50,000"), 250000)
        self.assertEqual(parse_amount("2cr"), 20_000_000)
        self.assertEqual(parse_amount(1500.5), 1500.5)

    def test_amount_rejections(self):
        for bad in ["", "abc", "-5", "0", "999", "1e9", "nan", "inf", "11cr", "5 bananas", "1,2,3x"]:
            with self.assertRaises(ValidationError, msg=bad):
                parse_amount(bad)

    def test_rate(self):
        self.assertEqual(parse_rate("8.5%"), 8.5)
        self.assertEqual(parse_rate("0"), 0.0)
        self.assertEqual(parse_rate("40"), 40.0)
        for bad in ["", "-1", "41", "x", "nan", "5.5.5"]:
            with self.assertRaises(ValidationError, msg=bad):
                parse_rate(bad)

    def test_tenure(self):
        self.assertEqual(parse_tenure("60"), 60)
        self.assertEqual(parse_tenure("5y"), 60)
        self.assertEqual(parse_tenure("2.5 years"), 30)
        self.assertEqual(parse_tenure("18 months"), 18)
        for bad in ["", "0", "361", "-3", "12.5", "1.3y", "abc", "30 days"]:
            with self.assertRaises(ValidationError, msg=bad):
                parse_tenure(bad)

    def test_dates(self):
        self.assertEqual(parse_date("2026-03-15"), date(2026, 3, 15))
        self.assertEqual(parse_date("15/03/2026"), date(2026, 3, 15))
        self.assertEqual(parse_date("", allow_blank=True), date.today())
        for bad in ["31/02/2025", "yesterday", "1999-01-01", "2099-01-01"]:
            with self.assertRaises(ValidationError, msg=bad):
                parse_date(bad)

    def test_text_and_choice(self):
        self.assertEqual(parse_text("  Asha   Verma "), "Asha Verma")
        for bad in ["", "A", "=SUM(A1)", "@home", "x" * 61, "bad<script>"]:
            with self.assertRaises(ValidationError, msg=bad):
                parse_text(bad)
        self.assertEqual(parse_choice("hom", config.LOAN_TYPES, "Type"), "Home")
        self.assertEqual(parse_choice("2", config.LOAN_TYPES, "Type"), "Car")
        with self.assertRaises(ValidationError):
            parse_choice("crypto", config.LOAN_TYPES, "Type")

    def test_build_record_reports_all_errors_at_once(self):
        with self.assertRaises(ValidationError) as ctx:
            build_record(valid_raw(borrower="", principal="abc", annual_rate="99", tenure_months="0"), 1)
        self.assertGreaterEqual(len(ctx.exception.messages), 4)

    def test_formatting(self):
        self.assertEqual(format_inr(12345678.5), "₹1,23,45,678.50")
        self.assertEqual(format_inr(999, 0), "₹999")
        self.assertEqual(format_inr(100000, 0), "₹1,00,000")
        self.assertEqual(short_inr(2_500_000), "25L")
        self.assertEqual(short_inr(30_000_000), "3Cr")


class StorageTests(unittest.TestCase):
    def test_missing_file_creates_clean_template(self):
        store, folder = temp_store(seed=False)
        self.assertTrue((folder / "loans.json").exists())
        self.assertEqual(store.records, [])

    def test_corrupt_json_is_backed_up_and_reset(self):
        store, folder = temp_store(seed=False)
        (folder / "loans.json").write_text("{ this is not json", encoding="utf-8")
        report = store.load()
        self.assertTrue(report.recovered)
        self.assertEqual(store.records, [])
        self.assertTrue(list(folder.glob("loans.corrupt-*.bak")))
        json.loads((folder / "loans.json").read_text(encoding="utf-8"))      # valid again

    def test_wrong_schema_is_recovered(self):
        store, folder = temp_store(seed=False)
        (folder / "loans.json").write_text('{"records": "oops"}', encoding="utf-8")
        self.assertTrue(store.load().recovered)

    def test_bad_entries_skipped_good_kept(self):
        store, folder = temp_store(seed=False)
        payload = {"records": [valid_raw(id=1), {"borrower": "X"}, "junk", valid_raw(id=1, borrower="Second One")]}
        (folder / "loans.json").write_text(json.dumps(payload), encoding="utf-8")
        report = store.load()
        self.assertEqual(report.loaded, 2)
        self.assertEqual(len(report.skipped), 2)
        self.assertEqual(len({r.id for r in store.records}), 2)               # duplicate ID was re-assigned

    def test_persistence_across_restart(self):
        store, folder = temp_store(seed=False)
        record = store.add_record(valid_raw())
        store.update(record.id, valid_raw(borrower="Renamed Person"))
        reopened = type(store)(folder / "loans.json", folder / "loans.csv", folder / "audit_log.txt")
        reopened.load()
        self.assertEqual([r.borrower for r in reopened.records], ["Renamed Person"])
        self.assertTrue((folder / "loans.csv").exists())
        reopened.delete(record.id)
        self.assertEqual(reopened.records, [])
        log = (folder / "audit_log.txt").read_text(encoding="utf-8")
        self.assertIn("ADD", log); self.assertIn("EDIT", log); self.assertIn("DELETE", log)

    def test_derived_fields_not_trusted_from_disk(self):
        store, folder = temp_store(seed=False)
        row = valid_raw(id=1); row["emi"] = 1.0
        (folder / "loans.json").write_text(json.dumps({"records": [row]}), encoding="utf-8")
        store.load()
        self.assertEqual(store.records[0].emi, 8678.23)

    def test_csv_formula_injection_neutralised(self):
        store, folder = temp_store(seed=False)
        store.add_record(valid_raw(notes="=1+1"))
        text = (folder / "loans.csv").read_text(encoding="utf-8")
        self.assertIn("'=1+1", text)

    def test_duplicate_detection(self):
        store, _ = temp_store(seed=False)
        first = store.add_record(valid_raw())
        self.assertIs(store.find_duplicate(store.make_record(valid_raw())), first)


if __name__ == "__main__":
    unittest.main()
