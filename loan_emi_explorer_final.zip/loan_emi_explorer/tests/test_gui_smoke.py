"""Runs every Streamlit page function against a stub, catching NameErrors, bad API usage in our own code
and broken data flows. (It cannot judge visual appearance - run `streamlit run gui_app.py` for that.)"""
import importlib
import unittest

from tests.helpers import ROOT, temp_store
from tests import stub_streamlit


class Upload:
    name = "legacy.csv"
    def __init__(self, data): self._data = data
    def getvalue(self): return self._data


class GuiSmoke(unittest.TestCase):
    def load(self, **cfg):
        self.st = stub_streamlit.install(cfg)
        self.gui = importlib.import_module("gui_app")
        return temp_store()[0]

    def tearDown(self):
        import sys
        sys.modules.pop("streamlit", None)
        sys.modules.pop("gui_app", None)

    def test_all_pages_render_with_data(self):
        store = self.load()
        for name, fn in self.gui.PAGE_FUNCS.items():
            fn(store)
        self.assertTrue(self.st.calls["pyplot"])
        self.assertTrue(self.st.calls["dataframe"])
        self.assertTrue(self.st.calls["metric"])
        self.assertEqual(self.st.calls["error"], [])

    def test_all_pages_render_when_empty(self):
        store, _ = temp_store(seed=False)
        self.st = stub_streamlit.install({})
        gui = importlib.import_module("gui_app")
        for fn in gui.PAGE_FUNCS.values():
            fn(store)

    def test_add_loan_validation_errors_and_success(self):
        store = self.load(SUBMIT=True)
        before = len(store.records)
        self.gui.page_add(store)                                  # blank borrower -> error shown, nothing saved
        self.assertTrue(self.st.calls["error"])
        self.assertEqual(len(store.records), before)
        self.st.config["TEXT"] = {"Borrower name": "Smoke Test"}
        self.gui.page_add(store)
        self.assertEqual(len(store.records), before + 1)
        self.assertTrue(self.st.calls["success"])

    def test_calculator_save_and_records_delete(self):
        store = self.load(SUBMIT=True, TEXT={"Borrower name": "Calc Saver"})
        before = len(store.records)
        self.gui.page_calculator(store)
        self.assertEqual(len(store.records), before + 1)
        self.st.config.update({"SUBMIT": False, "CHECK": True, "BUTTONS": ["Delete record"]})
        self.gui.page_records(store)
        self.assertEqual(len(store.records), before)

    def test_records_edit(self):
        store = self.load(SUBMIT=True, TEXT={"Borrower name": "Edited Name"})
        self.gui.page_records(store)
        self.assertIn("Edited Name", [r.borrower for r in store.records])

    def test_import_flow(self):
        data = (ROOT / "data" / "legacy_loans_import.csv").read_bytes()
        store = self.load(UPLOAD=Upload(data), BUTTONS=["Import"])
        store.records.clear()
        self.gui.page_import(store)
        self.assertEqual(len(store.records), 8)

    def test_export_page_buttons(self):
        store = self.load(BUTTONS=["Save all reports"])
        self.gui.page_export(store)
        self.assertGreaterEqual(len(self.st.calls["download_button"]), 4)

    def test_main_navigation(self):
        store = self.load(RADIO={"Navigate": "Alerts"})
        import emi.config as cfg
        self.gui.main()
        self.assertTrue(self.st.calls["set_page_config"])


if __name__ == "__main__":
    unittest.main()
