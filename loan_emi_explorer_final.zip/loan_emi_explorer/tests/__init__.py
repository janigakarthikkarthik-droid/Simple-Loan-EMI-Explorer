"""Tests run against a throw-away copy of the project's data/ and reports/ folders, never the real ones."""
import os
import shutil
import tempfile
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
_HOME = Path(tempfile.mkdtemp(prefix="emi_home_"))
shutil.copytree(_ROOT / "data", _HOME / "data")
os.environ["LOAN_EMI_HOME"] = str(_HOME)
