"""A tiny fake `streamlit` so the GUI code paths can be exercised without a browser (or without
Streamlit installed). It records what the pages render and returns widget defaults."""
import sys
import types
from collections import defaultdict


class Ctx:
    def __init__(self, mod):
        self._mod = mod
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getattr__(self, name): return getattr(self._mod, name)


def make_module(config=None):
    cfg = config or {}
    m = types.ModuleType("streamlit")
    m.calls = defaultdict(list)
    m.session_state = {}
    m.config = cfg                       # SUBMIT, TEXT, UPLOAD, BUTTONS, RADIO, SELECT

    def rec(name):
        def fn(*a, **k):
            m.calls[name].append((a, k))
        return fn
    for name in ["set_page_config", "markdown", "title", "caption", "subheader", "success", "error", "warning", "info",
                 "metric", "dataframe", "pyplot", "divider", "write", "stop"]:
        setattr(m, name, rec(name))

    m.columns = lambda spec, **k: [Ctx(m) for _ in range(spec if isinstance(spec, int) else len(spec))]
    m.tabs = lambda labels: [Ctx(m) for _ in labels]
    m.expander = lambda *a, **k: Ctx(m)
    m.form = lambda *a, **k: Ctx(m)
    m.sidebar = Ctx(m)
    m.rerun = lambda: m.calls["rerun"].append(())

    m.text_input = lambda label, value="", **k: cfg.get("TEXT", {}).get(label, value)
    m.number_input = lambda label, min_value=None, max_value=None, value=None, **k: value if value is not None else min_value
    m.slider = lambda label, lo, hi, value=None, step=None, **k: value if value is not None else lo
    m.selectbox = lambda label, options, index=0, **k: cfg.get("SELECT", {}).get(label, list(options)[index])
    m.multiselect = lambda label, options, default=None, **k: list(default or [])
    m.radio = lambda label, options, **k: cfg.get("RADIO", {}).get(label, list(options)[0])
    m.checkbox = lambda label, **k: cfg.get("CHECK", False)
    m.button = lambda label, **k: any(b in label for b in cfg.get("BUTTONS", []))
    m.form_submit_button = lambda label, **k: bool(cfg.get("SUBMIT", False))
    m.download_button = lambda *a, **k: m.calls["download_button"].append((a, k)) or False
    m.file_uploader = lambda *a, **k: cfg.get("UPLOAD")
    m.date_input = lambda label, value=None, **k: value
    return m


def install(config=None):
    m = make_module(config)
    sys.modules["streamlit"] = m
    sys.modules.pop("gui_app", None)
    return m
