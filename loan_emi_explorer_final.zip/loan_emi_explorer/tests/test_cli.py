"""End-to-end: drives the real terminal app through stdin, including deliberately bad input and a restart."""
import os
import shutil
import subprocess
import sys
import unittest

from tests.helpers import ROOT, temp_dir


def run_app(home, lines):
    env = {**os.environ, "LOAN_EMI_HOME": str(home), "NO_COLOR": "1", "PYTHONIOENCODING": "utf-8"}
    env.pop("FORCE_COLOR", None)
    proc = subprocess.run([sys.executable, str(ROOT / "app.py")], input="\n".join(lines) + "\n", capture_output=True,
                          text=True, encoding="utf-8", env=env, timeout=120)
    return proc.returncode, proc.stdout + proc.stderr


class CliJourney(unittest.TestCase):
    def setUp(self):
        self.home = temp_dir()
        shutil.copytree(ROOT / "data", self.home / "data")

    def test_demo_journey(self):
        code, out = run_app(self.home, [
            "2", "Demo Customer", "home", "abc", "-300000", "5 lakh", "50", "9", "400", "5y",
            "1,00,000", "31-02-2026", "2026-11-01", "active", "cli test", "",
            "0"])
        self.assertEqual(code, 0)
        for needle in ["must be a number", "cannot be negative", "between 0% and 40%", "between 1 and 360", "real date", "Saved as record #46"]:
            self.assertIn(needle, out)
        # persistence: relaunch and find the record again
        code, out = run_app(self.home, ["4", "demo customer", "", "", "", "", "", "n", "0"])
        self.assertIn("46 loan record(s) loaded", out)
        self.assertIn("1 of 46 records match", out)

    def test_every_menu_screen_runs(self):
        code, out = run_app(self.home, [
            "1", "7 lakh", "9.5", "5y", "n", "n",        # quick calc
            "3", "q",                                   # view (paged) then quit paging
            "6", "1", "q",                              # schedule for record 1
            "7", "8", "q",                              # summary, alerts
            "9", "9", "n",                              # all charts
            "10", "4",                                  # export everything
            "11", "", "y",                              # bulk import
            "5", "1", "3",                              # edit/delete -> back
            "banana", "99",                             # invalid menu choices
            "0"])
        self.assertEqual(code, 0, out[-800:])
        for needle in ["Result", "Amortization schedule", "Executive summary", "Threshold warnings", "Saved 7 chart image(s)",
                       "Wrote 4 file(s)", "Imported 8 record(s)", "Please enter a number from the menu", "Goodbye"]:
            self.assertIn(needle, out)
        self.assertNotIn("Traceback", out)
        self.assertNotIn("Unexpected problem", out)
        self.assertTrue(list((self.home / "reports").glob("emi_summary_*.md")))
        self.assertTrue(list((self.home / "reports").glob("import_errors_*.txt")))
        self.assertTrue(list((self.home / "reports" / "charts").glob("dashboard_*.png")))

    def test_survives_corrupt_data_file_and_eof(self):
        (self.home / "data" / "loans.json").write_text("not json at all", encoding="utf-8")
        code, out = run_app(self.home, ["3"])                   # input ends abruptly (EOF)
        self.assertEqual(code, 0)
        self.assertIn("unreadable", out)
        self.assertTrue(list((self.home / "data").glob("loans.corrupt-*.bak")))

    def test_cancel_returns_to_menu(self):
        code, out = run_app(self.home, ["2", "Someone", "cancel", "0"])
        self.assertIn("Cancelled", out)
        self.assertEqual(code, 0)


if __name__ == "__main__":
    unittest.main()
