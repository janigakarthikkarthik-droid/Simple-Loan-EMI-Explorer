#!/usr/bin/env python3
"""Simple Loan EMI Explorer - menu-driven terminal application.

    python app.py          # terminal interface
    python app.py --gui    # launch the Streamlit GUI instead
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import traceback
from datetime import datetime
from functools import partial
from pathlib import Path

from emi import __version__, alerts as alerts_mod, config, export, importer, search, summary
from emi.calculator import amortization_schedule, calculate_emi
from emi.models import LoanRecord
from emi.storage import LoanStore, StorageError
from emi.ui_helpers import (banner, bold, bad, dim, format_inr, months_text, ok, paginate, paint, render_table,
                            section, text_bar_chart, warn)
from emi.validation import (CancelInput, ValidationError, ask, confirm, optional, parse_amount, parse_choice,
                            parse_date, parse_income, parse_int_id, parse_notes, parse_rate, parse_tenure, parse_text)

try:                                   # matplotlib is optional: the app degrades to text charts without it
    from emi import charts
    CHARTS_OK = True
except ImportError:
    charts, CHARTS_OK = None, False

LEVEL_STYLE = {"critical": "red", "warning": "amber", "info": "cyan", "ok": "green"}
STATUS_STYLE = {"Active": "green", "Overdue": "red", "Pending": "amber", "Closed": "dim"}


# ----------------------------------------------------------------------- helpers
def money(v: float) -> str:
    return format_inr(v)


def print_kv(rows: list[tuple[str, str]], width: int = 24) -> None:
    for key, value in rows:
        print(f"  {dim(key.ljust(width))} {value}")


def record_table(records: list[LoanRecord], alert_list) -> None:
    flagged: dict[int, str] = {}
    for a in alert_list:
        if a.record_id not in flagged or alerts_mod.LEVEL_ORDER[a.level] < alerts_mod.LEVEL_ORDER[flagged[a.record_id]]:
            flagged[a.record_id] = a.level
    rows = []
    for r in records:
        level = flagged.get(r.id)
        flag = ("● " + level, LEVEL_STYLE[level]) if level else ("", None)
        rows.append([r.id, r.borrower, r.loan_type, money(r.principal), f"{r.annual_rate:g}%", r.tenure_months,
                     money(r.emi), (r.status, STATUS_STYLE.get(r.status)), flag])
    paginate(["ID", "Borrower", "Type", "Principal", "Rate", "Mths", "EMI", "Status", "Flag"], rows,
             [4, 20, 9, 16, 6, 4, 12, 8, 10], ["r", "l", "l", "r", "r", "r", "r", "l", "l"], config.PAGE_SIZE,
             "No records match.")


def record_card(r: LoanRecord, alert_list=None) -> None:
    section(f"Loan #{r.id} - {r.borrower}")
    print_kv([
        ("Type / status", f"{r.loan_type} / {paint(r.status, STATUS_STYLE.get(r.status, 'dim'))}"),
        ("Loan amount", money(r.principal)),
        ("Interest rate", f"{r.annual_rate:g}% per year"),
        ("Tenure", months_text(r.tenure_months)),
        ("Monthly EMI", bold(money(r.emi))),
        ("Total repayable", money(r.total_payment)),
        ("Total interest", f"{money(r.total_interest)}  ({r.total_interest / r.principal:.0%} of principal)"),
        ("Monthly income", money(r.monthly_income) if r.monthly_income else dim("not recorded")),
        ("EMI / income", f"{r.emi_income_ratio:.0%}" if r.emi_income_ratio is not None else dim("n/a")),
        ("Start → end", f"{r.start_date} → {r.end_date.isoformat()}"),
        ("Notes", r.notes or dim("-")),
    ])
    for a in (alert_list or []):
        print(paint(f"  ▲ {a.level.upper()}: {a.message}", LEVEL_STYLE[a.level]))


def show_calc(principal: float, rate: float, months: int) -> None:
    emi = calculate_emi(principal, rate, months)
    total = round(emi * months, 2)
    interest = round(total - principal, 2)
    section("Result")
    print_kv([("Monthly EMI", bold(ok(money(emi)))), ("Total repayable", money(total)),
              ("Total interest", f"{money(interest)}  ({interest / principal:.0%} of principal)"),
              ("Tenure", months_text(months))])


def open_with_viewer(path: Path) -> None:
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))                                   # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:                                                 # headless machine, no viewer, etc.
        print(dim("    (could not open a viewer automatically - open the file manually)"))


# ----------------------------------------------------------------------- actions
def action_quick_calc(store: LoanStore) -> None:
    section("Quick EMI calculator")
    print(dim("  Type 'cancel' at any prompt to go back."))
    principal = ask("Loan amount", parse_amount, hint="e.g. 500000, 5,00,000, 5 lakh, 2cr")
    rate = ask("Annual interest rate %", parse_rate, hint="0-40")
    months = ask("Tenure", parse_tenure, hint="months or years: 60, 60m, 5y")
    show_calc(principal, rate, months)
    if confirm("Show the month-by-month schedule?"):
        show_schedule(principal, rate, months)
    if confirm("Save this as a loan record?"):
        action_add(store, prefill={"principal": principal, "annual_rate": rate, "tenure_months": months})


def action_add(store: LoanStore, prefill: dict | None = None) -> None:
    section("Add loan record")
    print(dim("  Type 'cancel' at any prompt to go back."))
    p = prefill or {}
    print(dim(f"  Loan types: " + ", ".join(f"{i}={t}" for i, t in enumerate(config.LOAN_TYPES, 1))))
    raw = {
        "borrower": ask("Borrower name", parse_text),
        "loan_type": ask("Loan type", partial(parse_choice, choices=config.LOAN_TYPES, label="Loan type"), hint="name or number"),
        "principal": p.get("principal") or ask("Loan amount", parse_amount, hint="e.g. 500000, 5 lakh"),
        "annual_rate": p.get("annual_rate") if p.get("annual_rate") is not None else ask("Annual interest rate %", parse_rate, hint="0-40"),
        "tenure_months": p.get("tenure_months") or ask("Tenure", parse_tenure, hint="60, 60m, 5y"),
        "monthly_income": ask("Monthly income (optional)", parse_income, default="", hint="Enter to skip"),
        "start_date": ask("Start date", partial(parse_date, allow_blank=True), default=datetime.now().strftime("%Y-%m-%d"), hint="YYYY-MM-DD"),
        "status": ask("Status", partial(parse_choice, choices=config.STATUSES, label="Status", default="Active"), default="Active",
                      hint=", ".join(config.STATUSES)),
        "notes": ask("Notes (optional)", parse_notes, default="", hint="Enter to skip"),
    }
    record = store.make_record(raw)
    twin = store.find_duplicate(record)
    if twin and not confirm(warn(f"Looks identical to record #{twin.id}. Save anyway?")):
        print(dim("  Not saved."))
        return
    store.add(record)
    print(ok(f"\n  ✔ Saved as record #{record.id}."))
    record_card(record, alerts_mod.alerts_for(alerts_mod.generate_alerts(store.records), record.id))


def action_view(store: LoanStore) -> None:
    section(f"All loan records ({len(store.records)})")
    record_table(sorted(store.records, key=lambda r: r.id), alerts_mod.generate_alerts(store.records))


def action_search(store: LoanStore) -> None:
    section("Search & filter")
    print(dim("  Press Enter to skip any filter. Type 'cancel' to go back."))
    print(dim("  Types: " + ", ".join(config.LOAN_TYPES) + "   |   Statuses: " + ", ".join(config.STATUSES)))
    keyword = ask("Keyword (name, notes, type...)", str, default="")
    loan_type = ask("Loan type", optional(partial(parse_choice, choices=config.LOAN_TYPES, label="Loan type")), default="")
    status = ask("Status", optional(partial(parse_choice, choices=config.STATUSES, label="Status")), default="")
    min_emi = ask("Minimum EMI", optional(partial(parse_amount, label="Minimum EMI", lo=0)), default="")
    max_emi = ask("Maximum EMI", optional(partial(parse_amount, label="Maximum EMI", lo=0)), default="")
    sort_by = ask("Sort by", partial(parse_choice, choices=list(search.SORT_KEYS), label="Sort field", default="id"), default="id",
                  hint=", ".join(search.SORT_KEYS))
    results = search.search_records(store.records, keyword, [loan_type] if loan_type else None, [status] if status else None,
                                    min_emi, max_emi, sort_by=sort_by)
    print(f"\n  {bold(str(len(results)))} of {len(store.records)} records match.\n")
    record_table(results, alerts_mod.generate_alerts(store.records))
    if results and confirm("Show full details for one of them?"):
        record_id = ask("Record ID", parse_int_id)
        found = store.get(record_id)
        if found:
            record_card(found, alerts_mod.alerts_for(alerts_mod.generate_alerts(store.records), record_id))
        else:
            print(bad(f"  No record with ID {record_id}."))


def action_edit_delete(store: LoanStore) -> None:
    section("Edit or delete a record")
    record = store.get(ask("Record ID", parse_int_id))
    if record is None:
        print(bad("  No record with that ID."))
        return
    record_card(record)
    choice = ask("[1] Edit  [2] Delete  [3] Back", partial(parse_choice, choices=["1", "2", "3"], label="Choice", default="3"), default="3")
    if choice == "2":
        if confirm(warn(f"Delete #{record.id} {record.borrower} permanently?")):
            store.delete(record.id)
            print(ok("  ✔ Deleted."))
        return
    if choice == "3":
        return
    print(dim("  Press Enter to keep the current value."))
    raw = {
        "borrower": ask("Borrower name", parse_text, default=record.borrower),
        "loan_type": ask("Loan type", partial(parse_choice, choices=config.LOAN_TYPES, label="Loan type"), default=record.loan_type),
        "principal": ask("Loan amount", parse_amount, default=f"{record.principal:.2f}"),
        "annual_rate": ask("Annual interest rate %", parse_rate, default=f"{record.annual_rate:g}"),
        "tenure_months": ask("Tenure", parse_tenure, default=str(record.tenure_months)),
        "monthly_income": ask("Monthly income", parse_income, default=f"{record.monthly_income:.0f}" if record.monthly_income else ""),
        "start_date": ask("Start date", partial(parse_date, allow_blank=True), default=record.start_date),
        "status": ask("Status", partial(parse_choice, choices=config.STATUSES, label="Status"), default=record.status),
        "notes": ask("Notes", parse_notes, default=record.notes),
    }
    updated = store.update(record.id, raw)
    print(ok("  ✔ Updated."))
    record_card(updated, alerts_mod.alerts_for(alerts_mod.generate_alerts(store.records), updated.id))


def show_schedule(principal: float, rate: float, months: int) -> None:
    rows = amortization_schedule(principal, rate, months)
    section(f"Amortization schedule ({months} months)")
    table = [[r["month"], money(r["payment"]), money(r["principal_paid"]), money(r["interest"]), money(r["balance"])] for r in rows]
    paginate(["Month", "Payment", "Principal", "Interest", "Balance"], table, [5, 14, 14, 13, 15], ["r"] * 5, 12)
    print(f"  Total interest: {bold(money(rows[-1]['cumulative_interest']))}")


def action_schedule(store: LoanStore) -> None:
    section("Amortization schedule for a record")
    record = store.get(ask("Record ID", parse_int_id))
    if record is None:
        print(bad("  No record with that ID."))
        return
    show_schedule(record.principal, record.annual_rate, record.tenure_months)


def action_summary(store: LoanStore) -> None:
    s = summary.compute_summary(store.records)
    section("Executive summary")
    if not s["count"]:
        print(warn("  No records yet - add a loan or import a CSV first."))
        return
    health = s["health"]
    print_kv([
        ("Loans tracked", str(s["count"])),
        ("Total principal", money(s["total_principal"])),
        ("Total interest payable", money(s["total_interest"])),
        ("Total repayable", money(s["total_payable"])),
        ("Monthly obligation", f"{money(s['monthly_obligation'])}  (Active + Overdue loans)"),
        ("Average loan / median", f"{money(s['avg_principal'])} / {money(s['median_principal'])}"),
        ("Average rate / weighted", f"{s['avg_rate']:.2f}% / {s['weighted_rate']:.2f}%"),
        ("Average tenure", months_text(round(s["avg_tenure"]))),
        ("Average EMI", money(s["avg_emi"])),
        ("Highest EMI", f"{money(s['highest_emi'].emi)}  (#{s['highest_emi'].id} {s['highest_emi'].borrower})"),
        ("Lowest EMI", f"{money(s['lowest_emi'].emi)}  (#{s['lowest_emi'].id} {s['lowest_emi'].borrower})"),
        ("Portfolio health", paint(f"{health['label']} - {health['overdue']} overdue ({health['share']:.0%})", LEVEL_STYLE[health["level"]], "bold")),
        ("Warnings", f"{s['alert_counts']['critical']} critical, {s['alert_counts']['warning']} warning, {s['alert_counts']['info']} info"),
    ], 26)
    section("By loan type")
    print(render_table(["Type", "Loans", "Principal", "Interest", "Avg rate", "Avg EMI", "Share"],
                       [[d["type"], d["count"], money(d["principal"]).split(".")[0], money(d["interest"]).split(".")[0],
                         f"{d['avg_rate']:.2f}%", money(d["avg_emi"]).split(".")[0], f"{d['share']:.0%}"] for d in s["by_type"]],
                       [10, 5, 15, 15, 8, 11, 6], ["l", "r", "r", "r", "r", "r", "r"]))
    section("By status")
    print(render_table(["Status", "Loans", "Principal"],
                       [[(d["status"], STATUS_STYLE.get(d["status"])), d["count"], money(d["principal"]).split(".")[0]] for d in s["by_status"]],
                       [10, 5, 16], ["l", "r", "r"]))
    section("Lending trend (by start month, last 12 shown)")
    print(render_table(["Month", "Loans", "Principal", "Avg rate"],
                       [[d["month"], d["count"], money(d["principal"]).split(".")[0], f"{d['avg_rate']:.2f}%"] for d in s["trend"][-12:]],
                       [8, 5, 16, 9], ["l", "r", "r", "r"]))
    section("Key insights")
    for line in s["insights"]:
        print(f"  • {line}")


def action_alerts(store: LoanStore) -> None:
    section("Threshold warnings")
    found = alerts_mod.generate_alerts(store.records)
    if not found:
        print(ok("  ✔ No warnings - every loan is within the configured thresholds."))
        return
    counts = alerts_mod.count_by_level(found)
    print(f"  {paint(str(counts['critical']) + ' critical', 'red', 'bold')}   {paint(str(counts['warning']) + ' warning', 'amber', 'bold')}"
          f"   {paint(str(counts['info']) + ' info', 'cyan')}\n")
    rows = [[(a.level.upper(), LEVEL_STYLE[a.level]), a.record_id, a.borrower, a.message] for a in found]
    paginate(["Level", "ID", "Borrower", "Issue"], rows, [8, 4, 20, 78], ["l", "r", "l", "l"], 15)
    print(dim(f"  Thresholds: EMI > {config.EMI_INCOME_WARN:.0%}/{config.EMI_INCOME_CRIT:.0%} of income, rate > {config.HIGH_RATE_WARN:g}%/"
              f"{config.HIGH_RATE_CRIT:g}%, tenure ≥ {config.LONG_TENURE_MONTHS // 12} years, amount > {config.OUTLIER_MULTIPLE:g}x median of its type."))


def action_charts(store: LoanStore) -> None:
    section("Charts")
    if not store.records:
        print(warn("  No records yet - nothing to plot."))
        return
    if not CHARTS_OK:
        print(warn("  matplotlib is not installed (pip install matplotlib) - showing text charts instead.\n"))
        s = summary.compute_summary(store.records)
        print(bold("  Average EMI by loan type"))
        print(text_bar_chart([(d["type"], d["avg_emi"]) for d in s["by_type"]], formatter=lambda v: money(v).split(".")[0]))
        print(bold("\n  Loans by status"))
        print(text_bar_chart([(d["status"], d["count"]) for d in s["by_status"]]))
        return
    options = [("1", "Full dashboard (6 charts in one image)", "dashboard"),
               ("2", "Average EMI by loan type", "emi_by_type"), ("3", "Principal vs interest", "principal_vs_interest"),
               ("4", "EMI distribution", "emi_distribution"), ("5", "Lending trend over time", "trend"),
               ("6", "Loans by status", "status_mix"), ("7", "Largest EMIs", "top_emis"),
               ("8", "Balance curve for one loan", "balance"), ("9", "Generate every chart", "all"), ("0", "Back", None)]
    for key, label, _ in options:
        print(f"  {paint(key, 'teal', 'bold')}  {label}")
    choice = ask("Chart", partial(parse_choice, choices=[o[0] for o in options], label="Chart", default="0"), default="0")
    name = dict((k, n) for k, _, n in options)[choice]
    if name is None:
        return
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    saved: list[Path] = []
    if name == "balance":
        record = store.get(ask("Record ID", parse_int_id))
        if record is None:
            print(bad("  No record with that ID."))
            return
        saved.append(charts.save_figure(charts.record_balance_chart(record), config.CHARTS_DIR / f"balance_{record.id}_{stamp}.png"))
    elif name == "dashboard":
        saved.append(charts.save_figure(charts.dashboard(store.records), config.CHARTS_DIR / f"dashboard_{stamp}.png"))
    elif name == "all":
        saved.append(charts.save_figure(charts.dashboard(store.records), config.CHARTS_DIR / f"dashboard_{stamp}.png"))
        for key in charts.CHART_DRAWERS:
            saved.append(charts.save_figure(charts.chart(key, store.records), config.CHARTS_DIR / f"{key}_{stamp}.png"))
    else:
        saved.append(charts.save_figure(charts.chart(name, store.records), config.CHARTS_DIR / f"{name}_{stamp}.png"))
    store.audit("CHART", ", ".join(p.name for p in saved))
    print(ok(f"\n  ✔ Saved {len(saved)} chart image(s):"))
    for p in saved:
        print(f"    {config.rel(p)}")
    if confirm("Open the first one now?"):
        open_with_viewer(saved[0])


def action_export(store: LoanStore) -> None:
    section("Export reports")
    if not store.records:
        print(warn("  No records yet - nothing to export."))
        return
    options = {"1": "Markdown executive summary (.md)", "2": "Plain-text audit log (.txt)", "3": "Standardized CSV report (.csv)",
               "4": "Everything above + dashboard chart", "0": "Back"}
    for k, v in options.items():
        print(f"  {paint(k, 'teal', 'bold')}  {v}")
    choice = ask("Export", partial(parse_choice, choices=list(options), label="Export", default="0"), default="0")
    if choice == "0":
        return
    paths = {"1": lambda: [export.export_markdown(store.records)], "2": lambda: [export.export_audit(store.records)],
             "3": lambda: [export.export_csv(store.records)], "4": lambda: export.export_all(store.records)}[choice]()
    store.audit("EXPORT", ", ".join(p.name for p in paths))
    print(ok(f"\n  ✔ Wrote {len(paths)} file(s):"))
    for p in paths:
        print(f"    {config.rel(p)}")


def action_import(store: LoanStore) -> None:
    section("Bulk import from CSV")
    print(dim("  Accepts legacy files with different column names (Name/Type/Amount/Rate/Tenure...). Rows are validated one by one."))
    default = config.rel(config.LEGACY_SAMPLE_CSV) if config.LEGACY_SAMPLE_CSV.exists() else None
    path = Path(ask("CSV file path", lambda t: t.strip().strip('"') or (_ for _ in ()).throw(ValidationError("A file path is required.")),
                    default=default)).expanduser()
    if not path.is_absolute():
        path = config.HOME_DIR / path if (config.HOME_DIR / path).exists() else Path.cwd() / path
    try:
        result = importer.import_csv_file(path, store.records)
    except importer.ImportFormatError as exc:
        print(bad(f"  ✖ Import failed: {exc}"))
        return
    print(f"\n  {bold(result.summary)}")
    if result.ignored_columns:
        print(dim(f"  Ignored columns: {', '.join(result.ignored_columns)}"))
    if result.errors:
        print(warn(f"\n  Row-by-row problems ({len(result.errors)}):"))
        for err in result.errors[:15]:
            print(bad(f"    Row {err.row:>3}: ") + " ".join(err.messages))
        if len(result.errors) > 15:
            print(dim(f"    ... and {len(result.errors) - 15} more (see the log)."))
        log = importer.write_error_log(result)
        print(dim(f"  Full error log: {config.rel(log) if log else '-'}"))
    if not result.valid:
        print(warn("  Nothing valid to import."))
        return
    if confirm(f"Import the {len(result.valid)} valid row(s)?", default=True):
        added = store.add_many(result.valid)
        print(ok(f"  ✔ Imported {len(added)} record(s) (IDs {added[0].id}-{added[-1].id}). Data saved."))
    else:
        print(dim("  Nothing imported."))


def launch_gui(_store: LoanStore | None = None) -> None:
    gui = Path(__file__).resolve().parent / "gui_app.py"
    try:
        import streamlit  # noqa: F401
    except ImportError:
        print(bad("  ✖ Streamlit is not installed.") + " Run:  pip install streamlit matplotlib")
        return
    print(ok("  Starting the Streamlit GUI - press Ctrl+C in this window to stop it."))
    try:
        subprocess.run([sys.executable, "-m", "streamlit", "run", str(gui)], check=False)
    except KeyboardInterrupt:
        print(dim("\n  GUI stopped."))


# ---------------------------------------------------------------------- main loop
MENU = [
    ("1", "Quick EMI calculator", action_quick_calc), ("2", "Add loan record", action_add),
    ("3", "View all records", action_view), ("4", "Search & filter", action_search),
    ("5", "Edit / delete a record", action_edit_delete), ("6", "Amortization schedule", action_schedule),
    ("7", "Executive summary", action_summary), ("8", "Threshold warnings", action_alerts),
    ("9", "Charts", action_charts), ("10", "Export reports", action_export),
    ("11", "Bulk import (CSV)", action_import), ("12", "Launch GUI (Streamlit)", launch_gui),
]
HANDLERS = {key: fn for key, _, fn in MENU}


def print_menu() -> None:
    print()
    print(paint("  MAIN MENU", "teal", "bold"))
    for key, label, _ in MENU:
        print(f"  {paint(key.rjust(2), 'teal', 'bold')}  {label}")
    print(f"  {paint(' 0', 'teal', 'bold')}  Exit")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=config.APP_NAME)
    parser.add_argument("--gui", action="store_true", help="launch the Streamlit GUI instead of the terminal menu")
    args = parser.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if args.gui:
        launch_gui()
        return 0

    print(banner(config.APP_NAME, f"Estimate · Validate · Track · Report   v{__version__}"))
    store = LoanStore()
    try:
        report = store.load()
    except StorageError as exc:
        print(bad(f"\n  ✖ {exc}"))
        return 1
    for message in report.messages:
        print(warn(f"\n  ⚠ {message}"))
    for line in report.skipped[:5]:
        print(dim(f"    skipped {line}"))
    counts = alerts_mod.count_by_level(alerts_mod.generate_alerts(store.records))
    print(f"\n  {bold(str(len(store.records)))} loan record(s) loaded from {config.rel(config.JSON_FILE)}.")
    if counts["critical"] or counts["warning"]:
        print(warn(f"  ⚠ {counts['critical']} critical and {counts['warning']} warning flag(s) need attention - choose option 8."))

    while True:
        print_menu()
        try:
            choice = input("\n  Choose an option: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print(dim("\n  Goodbye!"))
            return 0
        if choice in ("0", "q", "quit", "exit"):
            print(ok("\n  Data is saved. Goodbye!"))
            return 0
        handler = HANDLERS.get(choice)
        if handler is None:
            print(bad("  ✖ Please enter a number from the menu (0-12)."))
            continue
        try:
            handler(store)
        except CancelInput:
            print(dim("\n  Cancelled - back to the main menu."))
        except KeyboardInterrupt:
            print(dim("\n  Interrupted - back to the main menu."))
        except EOFError:
            print(dim("\n  Input closed. Goodbye!"))
            return 0
        except ValidationError as exc:
            print(bad("  ✖ " + "; ".join(exc.messages)))
        except StorageError as exc:
            print(bad(f"  ✖ {exc}"))
        except Exception as exc:                                       # never let a bug end the session
            print(bad(f"  ✖ Unexpected problem: {type(exc).__name__}: {exc}"))
            if os.environ.get("LOAN_DEBUG"):
                traceback.print_exc()


if __name__ == "__main__":
    sys.exit(main())
