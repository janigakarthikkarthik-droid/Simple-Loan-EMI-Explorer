"""Simple Loan EMI Explorer - Streamlit GUI.

    streamlit run gui_app.py
or  python app.py --gui

Uses exactly the same backend modules (validation, storage, summary, charts, export, importer)
as the terminal app, so both front-ends read and write the same data/loans.json.
"""
from __future__ import annotations

import sys
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import streamlit as st

from emi import alerts as alerts_mod, charts, config, export, importer, search, summary
from emi.calculator import amortization_schedule, calculate_emi
from emi.storage import LoanStore, StorageError
from emi.ui_helpers import format_inr, months_text
from emi.validation import ValidationError, parse_amount, parse_tenure

PAGES = ["Dashboard", "EMI Calculator", "Add Loan", "Records", "Alerts", "Import", "Export"]
LEVEL_ICON = {"critical": "🔴", "warning": "🟠", "info": "🔵"}
HEALTH_ICON = {"ok": "🟢", "warning": "🟠", "critical": "🔴", "info": "⚪"}

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;500;600;700&display=swap');
html, body, [class*="css"], .stMarkdown, button, input, textarea { font-family: 'Schibsted Grotesk', system-ui, sans-serif; }
h1, h2, h3 { letter-spacing: -0.02em; color: #14262B; }
h1 { font-weight: 700; }
[data-testid="stSidebar"] { background: #0F3D40; }
[data-testid="stSidebar"] * { color: #E4F0F0 !important; }
[data-testid="stSidebar"] .stRadio label { padding: 4px 0; }
.hero { background: linear-gradient(120deg, #0F5257 0%, #14727A 100%); color: #fff; border-radius: 14px; padding: 22px 28px; margin-bottom: 18px; }
.hero h1 { color: #fff; margin: 0 0 4px 0; font-size: 1.9rem; }
.hero p { margin: 0; opacity: .85; }
.emi-figure { font-size: 3rem; font-weight: 700; color: #0F5257; line-height: 1.1; }
.emi-caption { color: #6B7C85; font-size: .9rem; }
[data-testid="stMetric"] { background: #fff; border: 1px solid #DCE5E8; border-left: 4px solid #0F5257; border-radius: 10px; padding: 10px 14px; }
.pill { display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: .8rem; font-weight: 600; }
.pill.ok { background: #DDF1E4; color: #17653A; } .pill.warning { background: #FDEBCB; color: #8A5A00; } .pill.critical { background: #F9DAD3; color: #9A2E18; }
</style>
"""


# ------------------------------------------------------------------------ helpers
def rerun() -> None:
    (getattr(st, "rerun", None) or st.experimental_rerun)()


def show_table(rows: list[dict]) -> None:
    """Full-width table; works across Streamlit versions."""
    try:
        st.dataframe(rows, width="stretch", hide_index=True)
    except TypeError:
        st.dataframe(rows, use_container_width=True, hide_index=True)


def show_figure(fig) -> None:
    st.pyplot(fig)


def flash(kind: str, message: str) -> None:
    st.session_state["flash"] = (kind, message)


def show_flash() -> None:
    item = st.session_state.pop("flash", None)
    if item:
        {"success": st.success, "error": st.error, "warning": st.warning}.get(item[0], st.info)(item[1])


def money(v: float, decimals: int = 0) -> str:
    return format_inr(v, decimals)


def record_rows(records) -> list[dict]:
    alert_list = alerts_mod.generate_alerts(records)
    worst: dict[int, str] = {}
    for a in alert_list:
        if a.record_id not in worst or alerts_mod.LEVEL_ORDER[a.level] < alerts_mod.LEVEL_ORDER[worst[a.record_id]]:
            worst[a.record_id] = a.level
    return [{"ID": r.id, "Borrower": r.borrower, "Type": r.loan_type, "Principal": money(r.principal),
             "Rate %": r.annual_rate, "Months": r.tenure_months, "EMI": money(r.emi, 2), "Status": r.status,
             "Start": r.start_date, "Ends": r.end_date.isoformat(),
             "Flag": LEVEL_ICON.get(worst.get(r.id, ""), "")} for r in records]


def loan_form(key: str, record=None, submit_label: str = "Save loan"):
    """Shared add/edit form. Returns the raw dict when submitted, else None."""
    today = date.today()
    with st.form(key, clear_on_submit=record is None):
        c1, c2 = st.columns(2)
        borrower = c1.text_input("Borrower name", value=record.borrower if record else "", max_chars=60)
        loan_type = c2.selectbox("Loan type", config.LOAN_TYPES,
                                 index=config.LOAN_TYPES.index(record.loan_type) if record else 0)
        c3, c4, c5 = st.columns(3)
        principal = c3.number_input("Loan amount (₹)", min_value=float(config.MIN_PRINCIPAL), max_value=float(config.MAX_PRINCIPAL),
                                    value=float(record.principal) if record else 500000.0, step=10000.0, format="%.0f")
        rate = c4.number_input("Annual interest rate (%)", min_value=float(config.MIN_RATE), max_value=float(config.MAX_RATE),
                               value=float(record.annual_rate) if record else 9.0, step=0.1, format="%.2f")
        tenure = c5.number_input("Tenure (months)", min_value=config.MIN_TENURE, max_value=config.MAX_TENURE,
                                 value=int(record.tenure_months) if record else 60, step=1)
        c6, c7, c8 = st.columns(3)
        income = c6.number_input("Monthly income (₹, optional)", min_value=0.0, max_value=float(config.MAX_INCOME),
                                 value=float(record.monthly_income) if record else 0.0, step=5000.0, format="%.0f")
        start = c7.date_input("Start date", value=record.start if record else today,
                              min_value=date(config.MIN_DATE_YEAR, 1, 1), max_value=today + timedelta(days=config.MAX_FUTURE_DAYS))
        status = c8.selectbox("Status", config.STATUSES, index=config.STATUSES.index(record.status) if record else 0)
        notes = st.text_input("Notes (optional)", value=record.notes if record else "", max_chars=200)
        submitted = st.form_submit_button(submit_label)
    if not submitted:
        return None
    return {"borrower": borrower, "loan_type": loan_type, "principal": principal, "annual_rate": rate, "tenure_months": int(tenure),
            "monthly_income": income, "start_date": start.isoformat(), "status": status, "notes": notes}


def show_errors(exc: ValidationError) -> None:
    for message in exc.messages:
        st.error(message)


# ------------------------------------------------------------------------- pages
def page_dashboard(store: LoanStore) -> None:
    s = summary.compute_summary(store.records)
    st.markdown(f'<div class="hero"><h1>{config.APP_NAME}</h1><p>Portfolio overview across {s["count"]} loan(s)</p></div>',
                unsafe_allow_html=True)
    if not s["count"]:
        st.info("No loans yet. Add one from **Add Loan**, or bring in a CSV from **Import**.")
        return
    c = st.columns(4)
    c[0].metric("Loans tracked", s["count"])
    c[1].metric("Total principal", money(s["total_principal"]))
    c[2].metric("Interest payable", money(s["total_interest"]))
    c[3].metric("Monthly obligation", money(s["monthly_obligation"]), help="Combined EMI of Active and Overdue loans")
    c = st.columns(4)
    c[0].metric("Average EMI", money(s["avg_emi"]))
    c[1].metric("Average rate", f"{s['avg_rate']:.2f}%", f"weighted {s['weighted_rate']:.2f}%", delta_color="off")
    c[2].metric("Average tenure", months_text(round(s["avg_tenure"])))
    health = s["health"]
    c[3].metric("Portfolio health", f"{HEALTH_ICON[health['level']]} {health['label']}", f"{health['overdue']} overdue", delta_color="off")

    counts = s["alert_counts"]
    if counts["critical"] or counts["warning"]:
        st.warning(f"{counts['critical']} critical and {counts['warning']} warning flag(s) - open **Alerts** for details.")

    st.subheader("Key insights")
    for line in s["insights"]:
        st.markdown(f"- {line}")

    tab_types, tab_status, tab_trend = st.tabs(["By loan type", "By status", "Monthly trend"])
    with tab_types:
        show_table([{"Type": d["type"], "Loans": d["count"], "Principal": money(d["principal"]), "Interest": money(d["interest"]),
                     "Avg rate %": d["avg_rate"], "Avg EMI": money(d["avg_emi"]), "Share": f"{d['share']:.0%}"} for d in s["by_type"]])
    with tab_status:
        show_table([{"Status": d["status"], "Loans": d["count"], "Principal": money(d["principal"])} for d in s["by_status"]])
    with tab_trend:
        show_table([{"Start month": d["month"], "Loans": d["count"], "Principal": money(d["principal"]), "Avg rate %": d["avg_rate"]}
                    for d in s["trend"]])

    st.subheader("Charts")
    left, right = st.columns(2)
    with left:
        show_figure(charts.chart("emi_by_type", store.records))
        show_figure(charts.chart("emi_distribution", store.records))
        show_figure(charts.chart("status_mix", store.records))
    with right:
        show_figure(charts.chart("principal_vs_interest", store.records))
        show_figure(charts.chart("trend", store.records))
        show_figure(charts.chart("top_emis", store.records))


def page_calculator(store: LoanStore) -> None:
    st.title("EMI Calculator")
    st.caption("Estimate the monthly payment for any loan - nothing is saved unless you choose to.")
    c1, c2, c3 = st.columns([2, 2, 2])
    principal = c1.number_input("Loan amount (₹)", min_value=float(config.MIN_PRINCIPAL), max_value=float(config.MAX_PRINCIPAL),
                                value=1_000_000.0, step=50_000.0, format="%.0f")
    rate = c2.slider("Annual interest rate (%)", float(config.MIN_RATE), float(config.MAX_RATE), 9.0, 0.05)
    t1, t2 = c3.columns([2, 1])
    tenure_value = t1.number_input("Tenure", min_value=1, max_value=config.MAX_TENURE, value=60, step=1)
    unit = t2.radio("Unit", ["months", "years"], horizontal=True)
    try:
        months = parse_tenure(f"{int(tenure_value)}{'y' if unit == 'years' else 'm'}")
        principal = parse_amount(principal)
    except ValidationError as exc:
        show_errors(exc)
        return

    emi = calculate_emi(principal, rate, months)
    total = round(emi * months, 2)
    interest = round(total - principal, 2)
    left, right = st.columns([1, 2])
    with left:
        st.markdown(f'<div class="emi-caption">Monthly EMI</div><div class="emi-figure">{money(emi, 2)}</div>', unsafe_allow_html=True)
        st.metric("Total repayable", money(total))
        st.metric("Total interest", money(interest), f"{interest / principal:.0%} of principal", delta_color="off")
        st.caption(f"Tenure: {months_text(months)}")
    with right:
        show_figure(charts.balance_chart(principal, rate, months, "How the balance falls month by month"))

    with st.expander("Month-by-month schedule"):
        rows = amortization_schedule(principal, rate, months)
        show_table([{"Month": r["month"], "Payment": money(r["payment"], 2), "Principal": money(r["principal_paid"], 2),
                     "Interest": money(r["interest"], 2), "Balance": money(r["balance"], 2)} for r in rows])

    with st.expander("Save this as a loan record"):
        with st.form("save_from_calc", clear_on_submit=True):
            c1, c2 = st.columns(2)
            borrower = c1.text_input("Borrower name")
            loan_type = c2.selectbox("Loan type", config.LOAN_TYPES, index=2)
            c3, c4 = st.columns(2)
            income = c3.number_input("Monthly income (₹, optional)", min_value=0.0, max_value=float(config.MAX_INCOME), value=0.0, step=5000.0, format="%.0f")
            status = c4.selectbox("Status", config.STATUSES)
            go = st.form_submit_button("Save loan")
        if go:
            raw = {"borrower": borrower, "loan_type": loan_type, "principal": principal, "annual_rate": rate, "tenure_months": months,
                   "monthly_income": income, "start_date": date.today().isoformat(), "status": status, "notes": ""}
            try:
                rec = store.add_record(raw)
                st.success(f"Saved as record #{rec.id}.")
            except ValidationError as exc:
                show_errors(exc)
            except StorageError as exc:
                st.error(str(exc))


def page_add(store: LoanStore) -> None:
    st.title("Add Loan")
    st.caption("Every field is validated before saving. Problems are listed so you can fix them in one go.")
    show_flash()
    raw = loan_form("add_loan")
    if raw is None:
        return
    try:
        record = store.make_record(raw)
        twin = store.find_duplicate(record)
        if twin:
            st.warning(f"This looks identical to record #{twin.id} ({twin.borrower}). It was saved anyway - delete one if it is a mistake.")
        store.add(record)
    except ValidationError as exc:
        show_errors(exc)
        return
    except StorageError as exc:
        st.error(str(exc))
        return
    st.success(f"Saved as record #{record.id}.")
    c = st.columns(3)
    c[0].metric("Monthly EMI", money(record.emi, 2))
    c[1].metric("Total repayable", money(record.total_payment))
    c[2].metric("Total interest", money(record.total_interest))
    for a in alerts_mod.alerts_for(alerts_mod.generate_alerts(store.records), record.id):
        {"critical": st.error, "warning": st.warning}.get(a.level, st.info)(a.message)


def page_records(store: LoanStore) -> None:
    st.title("Records")
    show_flash()
    if not store.records:
        st.info("No records yet.")
        return
    with st.expander("Search & filter", expanded=True):
        c1, c2, c3 = st.columns([2, 2, 2])
        keyword = c1.text_input("Keyword", placeholder="name, notes, type, ID...")
        types = c2.multiselect("Loan type", config.LOAN_TYPES)
        statuses = c3.multiselect("Status", config.STATUSES)
        c4, c5, c6 = st.columns(3)
        emi_values = [r.emi for r in store.records]
        lo, hi = float(min(emi_values)), float(max(emi_values))
        if hi > lo:
            emi_range = c4.slider("EMI range (₹)", lo, hi, (lo, hi))
        else:
            emi_range = (lo, hi)
        sort_by = c5.selectbox("Sort by", list(search.SORT_KEYS), index=0)
        descending = c6.checkbox("Descending")
    results = search.search_records(store.records, keyword, types or None, statuses or None,
                                    min_emi=emi_range[0] - 0.01, max_emi=emi_range[1] + 0.01, sort_by=sort_by, descending=descending)
    st.caption(f"{len(results)} of {len(store.records)} records")
    show_table(record_rows(results))
    if not results:
        return

    st.subheader("Inspect, edit or delete")
    labels = {f"#{r.id} - {r.borrower} ({r.loan_type}, {money(r.principal)})": r.id for r in results}
    chosen = st.selectbox("Choose a record", list(labels))
    record = store.get(labels[chosen])
    if record is None:
        return
    c = st.columns(4)
    c[0].metric("EMI", money(record.emi, 2))
    c[1].metric("Total interest", money(record.total_interest))
    c[2].metric("Tenure", months_text(record.tenure_months))
    c[3].metric("Ends", record.end_date.isoformat())
    for a in alerts_mod.alerts_for(alerts_mod.generate_alerts(store.records), record.id):
        {"critical": st.error, "warning": st.warning}.get(a.level, st.info)(a.message)
    tab_chart, tab_edit, tab_delete = st.tabs(["Balance curve", "Edit", "Delete"])
    with tab_chart:
        show_figure(charts.record_balance_chart(record))
    with tab_edit:
        raw = loan_form(f"edit_{record.id}", record, "Save changes")
        if raw is not None:
            try:
                store.update(record.id, raw)
                flash("success", f"Record #{record.id} updated.")
                rerun()
            except ValidationError as exc:
                show_errors(exc)
            except StorageError as exc:
                st.error(str(exc))
    with tab_delete:
        st.warning(f"Deleting #{record.id} ({record.borrower}) cannot be undone.")
        sure = st.checkbox("Yes, delete this record", key=f"del_ok_{record.id}")
        if st.button("Delete record", disabled=not sure, key=f"del_{record.id}"):
            try:
                store.delete(record.id)
                flash("success", f"Record #{record.id} deleted.")
                rerun()
            except StorageError as exc:
                st.error(str(exc))


def page_alerts(store: LoanStore) -> None:
    st.title("Alerts")
    found = alerts_mod.generate_alerts(store.records)
    counts = alerts_mod.count_by_level(found)
    c = st.columns(3)
    c[0].metric("🔴 Critical", counts["critical"])
    c[1].metric("🟠 Warning", counts["warning"])
    c[2].metric("🔵 Info", counts["info"])
    if not found:
        st.success("No warnings - every loan is within the configured thresholds.")
        return
    levels = st.multiselect("Show", ["critical", "warning", "info"], default=["critical", "warning"])
    shown = [a for a in found if a.level in levels]
    show_table([{"Level": f"{LEVEL_ICON[a.level]} {a.level}", "ID": a.record_id, "Borrower": a.borrower, "Issue": a.message} for a in shown])
    st.caption(f"Thresholds: EMI above {config.EMI_INCOME_WARN:.0%} / {config.EMI_INCOME_CRIT:.0%} of income, rate above "
               f"{config.HIGH_RATE_WARN:g}% / {config.HIGH_RATE_CRIT:g}%, tenure of {config.LONG_TENURE_MONTHS // 12}+ years, "
               f"amount above {config.OUTLIER_MULTIPLE:g}x the median of its loan type, overdue or past-maturity loans, duplicates. "
               f"Edit emi/config.py to change them.")


def page_import(store: LoanStore) -> None:
    st.title("Bulk Import")
    st.caption("Upload a legacy CSV. Column names like Name / Type / Amount / Rate / Tenure are recognised automatically, "
               "and every row is validated.")
    show_flash()
    st.download_button("Download a CSV template", importer.template_csv(), "loan_import_template.csv", "text/csv")
    upload = st.file_uploader("Choose a CSV file", type=["csv"])
    if upload is None:
        return
    data = upload.getvalue()
    text = None
    for encoding in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            text = data.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    try:
        result = importer.parse_csv_text(text or "", store.records, source=upload.name)
    except importer.ImportFormatError as exc:
        st.error(f"Import failed: {exc}")
        return
    c = st.columns(3)
    c[0].metric("Rows read", result.total_rows)
    c[1].metric("Valid", len(result.valid))
    c[2].metric("Rejected", len(result.errors))
    if result.ignored_columns:
        st.caption("Ignored columns: " + ", ".join(result.ignored_columns))
    if result.errors:
        st.subheader("Row-by-row problems")
        show_table([{"Row": e.row, "Problem": " ".join(e.messages)} for e in result.errors])
        st.download_button("Download error log", importer.error_log_text(result), "import_errors.txt", "text/plain")
    if result.valid:
        st.subheader("Rows ready to import")
        show_table([{"Borrower": v["borrower"], "Type": v["loan_type"], "Amount": v["principal"], "Rate": v["annual_rate"],
                     "Tenure": v["tenure_months"], "Start": v["start_date"]} for v in result.valid])
        if st.button(f"Import {len(result.valid)} valid row(s)", type="primary"):
            try:
                added = store.add_many(result.valid)
                flash("success", f"Imported {len(added)} record(s) (IDs {added[0].id}-{added[-1].id}).")
                rerun()
            except (ValidationError, StorageError) as exc:
                st.error(str(exc))


def page_export(store: LoanStore) -> None:
    st.title("Export")
    show_flash()
    if not store.records:
        st.info("Nothing to export yet.")
        return
    st.caption("Download straight to your computer, or write timestamped copies into the project's reports/ folder.")
    c1, c2, c3 = st.columns(3)
    c1.download_button("Markdown summary (.md)", export.markdown_report(store.records), "emi_summary.md", "text/markdown")
    c2.download_button("Audit log (.txt)", export.audit_report(store.records, store.audit_path), "emi_audit_log.txt", "text/plain")
    c3.download_button("CSV report (.csv)", export.csv_report(store.records), "emi_report.csv", "text/csv")
    fig = charts.dashboard(store.records)
    st.download_button("Dashboard image (.png)", charts.figure_bytes(fig), "emi_dashboard.png", "image/png")
    st.divider()
    if st.button("Save all reports to the reports/ folder"):
        try:
            paths = export.export_all(store.records, audit_path=store.audit_path)
            store.audit("EXPORT", ", ".join(p.name for p in paths))
            st.success("Saved: " + ", ".join(config.rel(p) for p in paths))
        except OSError as exc:
            st.error(f"Could not write reports: {exc}")
    with st.expander("Preview the Markdown report"):
        st.markdown(export.markdown_report(store.records))


# --------------------------------------------------------------------------- main
PAGE_FUNCS = {"Dashboard": page_dashboard, "EMI Calculator": page_calculator, "Add Loan": page_add, "Records": page_records,
              "Alerts": page_alerts, "Import": page_import, "Export": page_export}


def main() -> None:
    st.set_page_config(page_title=config.APP_NAME, page_icon="₹", layout="wide")
    st.markdown(CSS, unsafe_allow_html=True)
    store = LoanStore()
    try:
        report = store.load()
    except StorageError as exc:
        st.error(str(exc))
        st.stop()
        return
    for message in report.messages:
        st.warning(message)
    with st.sidebar:
        st.markdown(f"### {config.CURRENCY} {config.APP_NAME}")
        page = st.radio("Navigate", PAGES, label_visibility="collapsed")
        counts = alerts_mod.count_by_level(alerts_mod.generate_alerts(store.records))
        st.markdown("---")
        st.caption(f"{len(store.records)} loans · {counts['critical']} critical · {counts['warning']} warnings")
    PAGE_FUNCS[page](store)


if __name__ == "__main__":
    main()
