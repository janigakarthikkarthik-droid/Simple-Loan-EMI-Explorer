#!/usr/bin/env python3
"""Generate the demo datasets: 45 realistic loan records (JSON + CSV) and a messy legacy CSV
for the bulk-import demo. Deterministic - running it twice gives identical files.

    python generate_sample_data.py            # writes data/loans.json, loans.csv, sample_loans.*, legacy_loans_import.csv
"""
import csv
import json
import random
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from emi import config                                   # noqa: E402
from emi.models import add_months                        # noqa: E402
from emi.storage import LoanStore                         # noqa: E402

REFERENCE_DAY = date(2026, 11, 22)       # fixed so the shipped dataset is reproducible
rng = random.Random(17)

NAMES = ["Aarav Sharma", "Priya Nair", "Rohan Mehta", "Ananya Iyer", "Vikram Singh", "Sneha Reddy", "Karthik Rao",
         "Meera Pillai", "Arjun Kapoor", "Divya Menon", "Imran Qureshi", "Lakshmi Narayan", "Sanjay Gupta", "Pooja Desai",
         "Rahul Verma", "Neha Joshi", "Suresh Babu", "Fatima Sheikh", "Harish Patel", "Kavya Krishnan", "Manoj Tiwari",
         "Swati Bose", "Deepak Chauhan", "Ritu Agarwal", "Naveen Kumar", "Anjali Das", "Tarun Malhotra", "Shreya Ghosh",
         "Gopal Yadav", "Nisha Thomas", "Varun Bhatia", "Isha Saxena", "Prakash Hegde", "Rekha Naidu", "Amit Banerjee",
         "Bhavna Shah", "Yusuf Ansari", "Jyoti Kulkarni", "Ravi Teja", "Sunita Mishra", "Dinesh Pandey", "Mala Subramanian",
         "Kunal Arora", "Tanvi Rane", "Faisal Khan"]

PROFILES = {   # type: (amount range, rate range, tenure range in months, step)
    "Home": ((2_000_000, 15_000_000), (7.4, 9.6), (120, 300), 12),
    "Car": ((400_000, 2_000_000), (8.0, 11.5), (36, 84), 12),
    "Personal": ((50_000, 600_000), (11.0, 18.5), (12, 60), 6),
    "Education": ((300_000, 2_500_000), (8.2, 12.0), (36, 120), 12),
    "Business": ((500_000, 6_000_000), (11.0, 16.5), (24, 120), 12),
    "Gold": ((50_000, 800_000), (8.5, 12.5), (6, 36), 6),
}

# Hand-written edge cases: (borrower, type, principal, rate, tenure, income, start, status, notes)
EDGE_CASES = [
    ("Minimum Test Loan", "Personal", 1_000, 0, 1, 0, "2026-10-20", "Active", "Boundary: minimum amount, 0% rate, 1 month"),
    ("Corporate Mega Loan", "Business", 100_000_000, 9.0, 360, 30_000_000, "2025-04-01", "Active", "Boundary: maximum amount and tenure"),
    ("Zero Interest Scheme", "Education", 120_000, 0, 24, 45_000, "2025-08-10", "Active", "0% education subsidy"),
    ("Payday Lender Client", "Personal", 25_000, 40, 12, 18_000, "2026-03-05", "Overdue", "Boundary: maximum 40% rate"),
    ("Long Haul Mortgage", "Home", 5_000_000, 8.4, 360, 180_000, "2024-06-15", "Active", "30-year tenure"),
    ("Stretched Budget", "Car", 1_800_000, 10.5, 48, 55_000, "2026-02-01", "Active", "EMI above 50% of income"),
    ("Forgotten Closure", "Personal", 150_000, 12.0, 12, 70_000, "2025-01-10", "Active", "Tenure ended - still marked Active"),
    ("Late Payer One", "Gold", 200_000, 10.0, 12, 40_000, "2025-12-05", "Overdue", "Two missed instalments"),
    ("Upcoming Education", "Education", 900_000, 9.2, 60, 0, "2027-02-01", "Pending", "Disbursement next quarter"),
    ("Settled Early", "Home", 3_500_000, 8.1, 180, 150_000, "2023-03-01", "Closed", "Pre-closed"),
    ("Ravi Duplicate", "Car", 650_000, 9.5, 60, 85_000, "2026-05-18", "Active", "Entered twice by mistake"),
    ("Ravi Duplicate", "Car", 650_000, 9.5, 60, 85_000, "2026-05-18", "Active", "Entered twice by mistake"),
    ("Nearly Done", "Personal", 300_000, 13.0, 24, 65_000, "2024-12-20", "Active", "Final EMI due soon"),
]


def make_random_rows(count: int) -> list[tuple]:
    rows = []
    names = NAMES[:]
    rng.shuffle(names)
    types = list(PROFILES)
    for i in range(count):
        loan_type = types[i % len(types)]
        (lo, hi), (rlo, rhi), (tlo, thi), step = PROFILES[loan_type]
        principal = round(rng.uniform(lo, hi) / 10_000) * 10_000
        rate = round(rng.uniform(rlo, rhi), 2)
        tenure = rng.randrange(tlo, thi + 1, step) if thi - tlo >= step else tlo
        start = date(2023, 1, 1).toordinal() + rng.randrange(0, (date(2026, 10, 31) - date(2023, 1, 1)).days)
        start_date = date.fromordinal(start)
        ended = add_months(start_date, tenure) < REFERENCE_DAY
        roll = rng.random()
        status = ("Closed" if roll < 0.82 else "Overdue" if roll < 0.92 else "Active") if ended else ("Overdue" if roll < 0.07 else "Active")
        # monthly income chosen so EMI is roughly 12-38% of it; 1 in 5 rows leaves it blank
        from emi.calculator import calculate_emi
        emi = calculate_emi(principal, rate, tenure)
        income = 0 if rng.random() < 0.2 else int(round(emi / rng.uniform(0.12, 0.38) / 1000) * 1000)
        rows.append((names[i % len(names)], loan_type, principal, rate, tenure, income, start_date.isoformat(), status, ""))
    return rows


def write_legacy_import(path: Path) -> None:
    """A deliberately messy file: alternative headers, mixed formats, valid rows and every kind of bad row."""
    header = ["Name", "Type", "Amount", "Rate", "Tenure (months)", "Income", "Start Date", "Status", "Remarks"]
    rows = [
        ["Gaurav Mishra", "Home", "₹45,00,000", "8.65", "240", "1,40,000", "12/03/2025", "Active", "Legacy ledger row 1"],
        ["Shalini Rao", "Car", "7.5 lakh", "9.8", "60", "95000", "2025-09-02", "Active", "Amount typed in lakh"],
        ["Mohit Jain", "Personal", "180000", "14", "30", "52000", "05-01-2026", "Active", ""],
        ["Padma Lakshmi", "Education", "12,00,000", "10.25", "96", "", "2024-07-15", "Active", "No income recorded"],
        ["Uday Shankar", "Gold", "3.2 lakh", "11", "18", "38000", "2026-06-30", "Active", ""],
        ["Zoya Ahmed", "Business", "2cr", "12.5", "84", "450000", "2025-11-11", "Active", "Amount typed as 2cr"],
        ["Bharat Seth", "Personal", "95000", "15.5", "24", "41000", "2026-08-01", "Pending", ""],
        ["Charu Dutt", "Home", "6500000", "8.9", "300", "210000", "2023-05-20", "Active", ""],
        ["Omkar Patil", "Car", "-350000", "9.5", "48", "70000", "2025-02-14", "Active", "BAD: negative amount"],
        ["Leela Kurian", "Personal", "200000", "55", "36", "60000", "2025-04-10", "Active", "BAD: rate above 40%"],
        ["Ramesh Iyengar", "Gold", "150000", "10", "", "45000", "2025-06-01", "Active", "BAD: tenure missing"],
        ["Sita Ram", "Business", "abc", "12", "60", "90000", "2025-03-03", "Active", "BAD: amount is not a number"],
        ["Tejas Kamat", "Home", "4000000", "8.5", "400", "150000", "2024-01-01", "Active", "BAD: tenure above 360"],
        ["Usha Rani", "Crypto", "300000", "10", "24", "50000", "2025-05-05", "Active", "BAD: unknown loan type"],
        ["", "Personal", "100000", "12", "12", "30000", "2025-05-05", "Active", "BAD: borrower missing"],
        ["=HYPERLINK(\"http://x\")", "Personal", "100000", "12", "12", "30000", "2025-05-05", "Active", "BAD: formula in name"],
        ["Vijay Anand", "Car", "500000", "9", "48", "80000", "31/02/2025", "Active", "BAD: impossible date"],
        ["Wasim Raja", "Personal", "100000", "12", "12", "30000", "2025-05-05", "Active", "BAD: extra", "stray", "cells"],
        ["Gaurav Mishra", "Home", "₹45,00,000", "8.65", "240", "1,40,000", "12/03/2025", "Active", "BAD: duplicate of row 2"],
    ]
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(header)
        writer.writerows(rows)


def main() -> None:
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    rows = EDGE_CASES + make_random_rows(45 - len(EDGE_CASES))
    rows.sort(key=lambda r: r[6])
    store = LoanStore(config.DATA_DIR / "sample_loans.json", config.DATA_DIR / "sample_loans.csv", config.DATA_DIR / "_sample_audit.txt")
    keys = ["borrower", "loan_type", "principal", "annual_rate", "tenure_months", "monthly_income", "start_date", "status", "notes"]
    store.records = []
    for row in rows:
        store.records.append(store.make_record(dict(zip(keys, row))))
    store.save()
    (config.DATA_DIR / "_sample_audit.txt").unlink(missing_ok=True)
    # the live data files start from the same dataset
    (config.DATA_DIR / "loans.json").write_text((config.DATA_DIR / "sample_loans.json").read_text(encoding="utf-8"), encoding="utf-8")
    (config.DATA_DIR / "loans.csv").write_text((config.DATA_DIR / "sample_loans.csv").read_text(encoding="utf-8"), encoding="utf-8")
    write_legacy_import(config.LEGACY_SAMPLE_CSV)
    print(f"Wrote {len(store.records)} records to data/loans.json, data/loans.csv (+ sample_loans.*)")
    print(f"Wrote messy import demo file: {config.LEGACY_SAMPLE_CSV.relative_to(config.BASE_DIR)}")


if __name__ == "__main__":
    main()
