"""Defensive input validation.

Pure parsers (parse_*) raise ValidationError and are shared by the terminal app, the
Streamlit GUI, the file loader and the bulk importer. `ask()` wraps any parser in a loop
that keeps prompting until the value is valid, so the terminal app can never crash on
blank, non-numeric or out-of-range input.
"""
from __future__ import annotations

import math
import re
from datetime import date, datetime, timedelta
from typing import Any, Callable, Iterable, Mapping

from . import config
from .models import LoanRecord
from .ui_helpers import bad, dim, format_inr


class ValidationError(ValueError):
    """Raised with one or more human-readable messages."""

    def __init__(self, messages: str | Iterable[str]):
        self.messages = [messages] if isinstance(messages, str) else list(messages)
        super().__init__("; ".join(self.messages))


class CancelInput(Exception):
    """User typed 'cancel' at a prompt."""


# --------------------------------------------------------------------------- parsers
def _clean(value: Any) -> str:
    return "" if value is None else str(value).strip()


_MULTIPLIERS = {"": 1.0, "k": 1e3, "m": 1e6, "l": 1e5, "lac": 1e5, "lacs": 1e5,
                "lakh": 1e5, "lakhs": 1e5, "cr": 1e7, "crore": 1e7, "crores": 1e7}
_AMOUNT_RE = re.compile(r"^(\d+(?:\.\d+)?|\.\d+)\s*([a-z]*)$")
_NUMBER_RE = re.compile(r"^(\d+(?:\.\d+)?|\.\d+)$")


def parse_amount(value: Any, label: str = "Loan amount", lo: float = config.MIN_PRINCIPAL,
                 hi: float = config.MAX_PRINCIPAL) -> float:
    text = _clean(value)
    if not text:
        raise ValidationError(f"{label} is required.")
    t = text.lower()
    for junk in ("₹", "rs.", "rs", "inr", ",", "_"):
        t = t.replace(junk, "")
    t = t.strip()
    if t.startswith("-"):
        raise ValidationError(f"{label} cannot be negative (got '{text}').")
    match = _AMOUNT_RE.match(t)
    if not match or match.group(2) not in _MULTIPLIERS:
        raise ValidationError(f"{label} must be a number such as 500000, 5,00,000, 5 lakh or 2cr (got '{text}').")
    amount = round(float(match.group(1)) * _MULTIPLIERS[match.group(2)], 2)
    if not math.isfinite(amount) or amount < lo or amount > hi:
        raise ValidationError(f"{label} must be between {format_inr(lo, 0)} and {format_inr(hi, 0)} (got '{text}').")
    return amount


def parse_income(value: Any) -> float:
    """Monthly income is optional: blank means 'not provided' (0)."""
    if not _clean(value):
        return 0.0
    return parse_amount(value, "Monthly income", lo=0.0, hi=config.MAX_INCOME)


def parse_rate(value: Any, label: str = "Interest rate") -> float:
    text = _clean(value).replace("%", "").strip()
    if not text:
        raise ValidationError(f"{label} is required.")
    if text.startswith("-"):
        raise ValidationError(f"{label} cannot be negative (got '{value}').")
    if not _NUMBER_RE.match(text):
        raise ValidationError(f"{label} must be a number such as 8.5 (got '{value}').")
    rate = float(text)
    if rate < config.MIN_RATE or rate > config.MAX_RATE:
        raise ValidationError(f"{label} must be between {config.MIN_RATE:g}% and {config.MAX_RATE:g}% per year (got {rate:g}%).")
    return rate


_TENURE_RE = re.compile(r"^(\d+(?:\.\d+)?)(m|mo|mos|month|months|y|yr|yrs|year|years)?$")


def parse_tenure(value: Any, label: str = "Tenure") -> int:
    """Accepts '60', '60m', '18 months', '5y', '2.5 years'. Plain numbers are months."""
    text = _clean(value)
    if not text:
        raise ValidationError(f"{label} is required.")
    t = text.lower().replace(" ", "")
    if t.startswith("-"):
        raise ValidationError(f"{label} cannot be negative (got '{text}').")
    match = _TENURE_RE.match(t)
    if not match:
        raise ValidationError(f"{label} must look like 60, 60m, 18 months or 5y (got '{text}').")
    number, unit = float(match.group(1)), match.group(2) or "m"
    if unit.startswith("y"):
        months_float = number * 12
        if abs(months_float - round(months_float)) > 1e-9:
            raise ValidationError(f"{label} must be a whole number of months (got '{text}').")
        months = int(round(months_float))
    else:
        if number != int(number):
            raise ValidationError(f"{label} in months must be a whole number (got '{text}').")
        months = int(number)
    if months < config.MIN_TENURE or months > config.MAX_TENURE:
        raise ValidationError(f"{label} must be between {config.MIN_TENURE} and {config.MAX_TENURE} months "
                              f"({config.MAX_TENURE // 12} years) (got '{text}').")
    return months


_DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d")


def parse_date(value: Any, label: str = "Start date", allow_blank: bool = True) -> date:
    text = _clean(value)
    today = date.today()
    if not text:
        if allow_blank:
            return today
        raise ValidationError(f"{label} is required.")
    parsed = None
    for fmt in _DATE_FORMATS:
        try:
            parsed = datetime.strptime(text, fmt).date()
            break
        except ValueError:
            continue
    if parsed is None:
        raise ValidationError(f"{label} must be a real date like 2026-03-15 or 15/03/2026 (got '{text}').")
    if parsed.year < config.MIN_DATE_YEAR or parsed > today + timedelta(days=config.MAX_FUTURE_DAYS):
        raise ValidationError(f"{label} must be between {config.MIN_DATE_YEAR}-01-01 and "
                              f"{(today + timedelta(days=config.MAX_FUTURE_DAYS)).isoformat()} (got '{text}').")
    return parsed


_NAME_RE = re.compile(r"^[\w .,'&()/-]+$", re.UNICODE)


def parse_text(value: Any, label: str = "Borrower name", min_len: int = 2, max_len: int = 60) -> str:
    text = " ".join(_clean(value).split())
    if not text:
        raise ValidationError(f"{label} is required.")
    if len(text) < min_len or len(text) > max_len:
        raise ValidationError(f"{label} must be {min_len}-{max_len} characters (got {len(text)}).")
    if text[0] in "=+-@":
        raise ValidationError(f"{label} cannot start with '{text[0]}' (it could be run as a spreadsheet formula).")
    if not _NAME_RE.match(text):
        raise ValidationError(f"{label} may only contain letters, digits, spaces and . , ' & ( ) / - (got '{text}').")
    return text


def parse_notes(value: Any, max_len: int = 200) -> str:
    text = " ".join(_clean(value).split())
    if len(text) > max_len:
        raise ValidationError(f"Notes must be at most {max_len} characters (got {len(text)}).")
    if any(ord(ch) < 32 for ch in text):
        raise ValidationError("Notes contain control characters.")
    return text


def parse_choice(value: Any, choices: list[str], label: str, default: str | None = None) -> str:
    """Accepts the exact name, a unique prefix, or the 1-based menu number."""
    text = _clean(value)
    if not text:
        if default is not None:
            return default
        raise ValidationError(f"{label} is required. Choose one of: {', '.join(choices)}.")
    if text.isdigit() and 1 <= int(text) <= len(choices):
        return choices[int(text) - 1]
    lowered = text.lower()
    for choice in choices:
        if choice.lower() == lowered:
            return choice
    matches = [c for c in choices if c.lower().startswith(lowered)]
    if len(matches) == 1:
        return matches[0]
    raise ValidationError(f"{label} must be one of: {', '.join(choices)} (got '{text}').")


def parse_int_id(value: Any, label: str = "Record ID") -> int:
    text = _clean(value).lstrip("#")
    if not text.isdigit() or int(text) <= 0:
        raise ValidationError(f"{label} must be a positive whole number (got '{value}').")
    return int(text)


def optional(parser: Callable[[Any], Any]) -> Callable[[Any], Any]:
    """Wrap a parser so a blank answer means 'skip this filter' (None)."""
    return lambda value: None if not _clean(value) else parser(value)


# ------------------------------------------------------------------ record builder
def build_record(raw: Mapping[str, Any], record_id: int) -> LoanRecord:
    """Validate every field of a raw mapping; report ALL problems at once."""
    errors: list[str] = []

    def grab(fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except ValidationError as exc:
            errors.extend(exc.messages)
            return None

    borrower = grab(parse_text, raw.get("borrower"), "Borrower name")
    loan_type = grab(parse_choice, raw.get("loan_type"), config.LOAN_TYPES, "Loan type")
    principal = grab(parse_amount, raw.get("principal"))
    rate = grab(parse_rate, raw.get("annual_rate"))
    tenure = grab(parse_tenure, raw.get("tenure_months"))
    income = grab(parse_income, raw.get("monthly_income"))
    start = grab(parse_date, raw.get("start_date"), "Start date", True)
    status = grab(parse_choice, raw.get("status"), config.STATUSES, "Status", "Active")
    notes = grab(parse_notes, raw.get("notes"))
    if errors:
        raise ValidationError(errors)
    return LoanRecord(id=record_id, borrower=borrower, loan_type=loan_type, principal=principal,
                      annual_rate=rate, tenure_months=tenure, monthly_income=income,
                      start_date=start.isoformat(), status=status, notes=notes)


# --------------------------------------------------------------- interactive loops
def ask(label: str, parser: Callable[[Any], Any], default: Any = None, hint: str = "") -> Any:
    """Prompt until `parser` accepts the answer. Type 'cancel' to abort."""
    shown_default = f" [{default}]" if default not in (None, "") else ""
    shown_hint = f" ({hint})" if hint else ""
    while True:
        text = input(f"  {label}{shown_hint}{shown_default}: ").strip()
        if text.lower() in ("cancel", ":q"):
            raise CancelInput()
        if not text and default is not None:
            text = str(default)
        try:
            return parser(text)
        except ValidationError as exc:
            for message in exc.messages:
                print(bad(f"    ✖ {message}"))
            print(dim("    Try again, or type 'cancel' to go back."))


def confirm(label: str, default: bool = False) -> bool:
    suffix = "[Y/n]" if default else "[y/N]"
    while True:
        text = input(f"  {label} {suffix}: ").strip().lower()
        if not text:
            return default
        if text in ("y", "yes"):
            return True
        if text in ("n", "no"):
            return False
        print(bad("    ✖ Please answer y or n."))
