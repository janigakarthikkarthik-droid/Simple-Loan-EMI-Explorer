"""Multi-format exports: Markdown summary, plain-text audit log and standardized CSV report."""
from __future__ import annotations

import csv
import io
from datetime import datetime
from pathlib import Path

from . import config
from .alerts import generate_alerts
from .models import LoanRecord
from .storage import CSV_FIELDS, csv_safe
from .summary import compute_summary
from .ui_helpers import format_inr, months_text


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _md_table(headers: list[str], rows: list[list]) -> str:
    out = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    out += ["| " + " | ".join(str(c).replace("|", "\\|") for c in row) + " |" for row in rows]
    return "\n".join(out)


# ----------------------------------------------------------------------- content
def markdown_report(records: list[LoanRecord]) -> str:
    s = compute_summary(records)
    alerts = generate_alerts(records)
    lines = [f"# {config.APP_NAME} - Executive Summary", "",
             f"_Generated {datetime.now():%d %b %Y, %H:%M}_", "",
             "## Headline numbers", "",
             _md_table(["Metric", "Value"], [
                 ["Loans tracked", s["count"]],
                 ["Total principal", format_inr(s["total_principal"])],
                 ["Total interest payable", format_inr(s["total_interest"])],
                 ["Total repayable", format_inr(s["total_payable"])],
                 ["Monthly obligation (Active + Overdue)", format_inr(s["monthly_obligation"])],
                 ["Average loan size", format_inr(s["avg_principal"])],
                 ["Average / weighted rate", f"{s['avg_rate']:.2f}% / {s['weighted_rate']:.2f}%"],
                 ["Average tenure", months_text(round(s["avg_tenure"]))],
                 ["Average EMI", format_inr(s["avg_emi"])],
                 ["Portfolio health", f"{s['health']['label']} ({s['health']['overdue']} overdue, {s['health']['share']:.0%})"],
             ]), ""]
    if s["count"]:
        lines += ["## Key insights", ""] + [f"- {i}" for i in s["insights"]] + ["",
                  "## By loan type", "",
                  _md_table(["Type", "Loans", "Principal", "Interest", "Avg rate", "Avg EMI", "Share"],
                            [[d["type"], d["count"], format_inr(d["principal"], 0), format_inr(d["interest"], 0),
                              f"{d['avg_rate']:.2f}%", format_inr(d["avg_emi"], 0), f"{d['share']:.0%}"] for d in s["by_type"]]), "",
                  "## By status", "",
                  _md_table(["Status", "Loans", "Principal"], [[d["status"], d["count"], format_inr(d["principal"], 0)] for d in s["by_status"]]), "",
                  "## Monthly trend", "",
                  _md_table(["Start month", "Loans", "Principal", "Avg rate"],
                            [[d["month"], d["count"], format_inr(d["principal"], 0), f"{d['avg_rate']:.2f}%"] for d in s["trend"]]), ""]
    lines += ["## Warnings", ""]
    if alerts:
        lines.append(_md_table(["Level", "ID", "Borrower", "Issue"], [[a.level.upper(), a.record_id, a.borrower, a.message] for a in alerts]))
    else:
        lines.append("No warnings - everything is within thresholds.")
    lines += ["", "## All records", "",
              _md_table(["ID", "Borrower", "Type", "Principal", "Rate", "Tenure", "EMI", "Status"],
                        [[r.id, r.borrower, r.loan_type, format_inr(r.principal, 0), f"{r.annual_rate:g}%", f"{r.tenure_months} mo",
                          format_inr(r.emi), r.status] for r in records]), ""]
    return "\n".join(lines)


def audit_report(records: list[LoanRecord], audit_path: Path = config.AUDIT_FILE) -> str:
    s = compute_summary(records)
    alerts = generate_alerts(records)
    flags: dict[int, list[str]] = {}
    for a in alerts:
        flags.setdefault(a.record_id, []).append(a.code)
    rule = "=" * 78
    out = [rule, f"{config.APP_NAME} - AUDIT LOG", f"Generated: {datetime.now():%Y-%m-%d %H:%M:%S}", rule, "",
           "SUMMARY",
           f"  Records            : {s['count']}",
           f"  Total principal    : {format_inr(s['total_principal'])}",
           f"  Total interest     : {format_inr(s['total_interest'])}",
           f"  Monthly obligation : {format_inr(s['monthly_obligation'])}",
           f"  Warnings           : {s['alert_counts']['critical']} critical, {s['alert_counts']['warning']} warning, {s['alert_counts']['info']} info",
           f"  Portfolio health   : {s['health']['label']}", "", "THRESHOLD WARNINGS"]
    out += [f"  [{a.level.upper():<8}] #{a.record_id:<4} {a.borrower:<22} {a.message}" for a in alerts] or ["  none"]
    out += ["", "RECORD LEDGER", f"  {'ID':<4} {'BORROWER':<22} {'TYPE':<10} {'PRINCIPAL':>16} {'RATE':>6} {'MONTHS':>6} {'EMI':>14} {'STATUS':<8} FLAGS"]
    for r in records:
        out.append(f"  {r.id:<4} {r.borrower[:22]:<22} {r.loan_type:<10} {format_inr(r.principal):>16} {r.annual_rate:>5g}% "
                   f"{r.tenure_months:>6} {format_inr(r.emi):>14} {r.status:<8} {','.join(flags.get(r.id, [])) or '-'}")
    out += ["", "RECENT ACTIVITY (data/audit_log.txt, last 40 entries)"]
    try:
        history = Path(audit_path).read_text(encoding="utf-8").splitlines()[-40:]
        out += [f"  {line}" for line in history] or ["  none"]
    except OSError:
        out.append("  no activity log found")
    return "\n".join(out) + "\n"


def csv_report(records: list[LoanRecord]) -> str:
    alerts = generate_alerts(records)
    flags: dict[int, list[str]] = {}
    for a in alerts:
        flags.setdefault(a.record_id, []).append(a.code)
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=CSV_FIELDS + ["end_date", "emi_to_income", "warning_flags"], lineterminator="\n")
    writer.writeheader()
    for r in records:
        row = {k: csv_safe(v) for k, v in r.to_dict().items() if k in CSV_FIELDS}
        row["end_date"] = r.end_date.isoformat()
        row["emi_to_income"] = f"{r.emi_income_ratio:.3f}" if r.emi_income_ratio is not None else ""
        row["warning_flags"] = ";".join(flags.get(r.id, []))
        writer.writerow(row)
    return buffer.getvalue()


# ------------------------------------------------------------------- file writers
def _write(name: str, text: str, folder: Path) -> Path:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / name
    path.write_text(text, encoding="utf-8", newline="")
    return path


def export_markdown(records, folder: Path = config.REPORTS_DIR) -> Path:
    return _write(f"emi_summary_{_stamp()}.md", markdown_report(records), folder)


def export_audit(records, folder: Path = config.REPORTS_DIR, audit_path: Path = config.AUDIT_FILE) -> Path:
    return _write(f"emi_audit_log_{_stamp()}.txt", audit_report(records, audit_path), folder)


def export_csv(records, folder: Path = config.REPORTS_DIR) -> Path:
    return _write(f"emi_report_{_stamp()}.csv", csv_report(records), folder)


def export_all(records, folder: Path = config.REPORTS_DIR, audit_path: Path = config.AUDIT_FILE) -> list[Path]:
    paths = [export_markdown(records, folder), export_audit(records, folder, audit_path), export_csv(records, folder)]
    try:                                   # chart image is optional - matplotlib may be missing
        from . import charts
        paths.append(charts.save_figure(charts.dashboard(records), Path(folder) / "charts" / f"dashboard_{_stamp()}.png"))
    except ImportError:
        pass
    return paths
