"""Simple Loan EMI Explorer - core package (pure standard library except charts)."""
__version__ = "1.0.0"
