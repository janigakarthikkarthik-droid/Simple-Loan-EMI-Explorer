"""Core business logic: EMI, totals and amortization schedule."""
from __future__ import annotations


def monthly_rate(annual_rate: float) -> float:
    """Annual percentage rate -> monthly decimal rate."""
    return annual_rate / 12.0 / 100.0


def calculate_emi(principal: float, annual_rate: float, months: int) -> float:
    """EMI = P*r*(1+r)^n / ((1+r)^n - 1); falls back to P/n when the rate is 0%."""
    if principal <= 0:
        raise ValueError("principal must be positive")
    if months <= 0:
        raise ValueError("months must be positive")
    if annual_rate < 0:
        raise ValueError("rate cannot be negative")
    r = monthly_rate(annual_rate)
    if r == 0:
        return round(principal / months, 2)
    factor = (1 + r) ** months
    return round(principal * r * factor / (factor - 1), 2)


def total_payment(principal: float, annual_rate: float, months: int) -> float:
    return round(calculate_emi(principal, annual_rate, months) * months, 2)


def total_interest(principal: float, annual_rate: float, months: int) -> float:
    return round(total_payment(principal, annual_rate, months) - principal, 2)


def amortization_schedule(principal: float, annual_rate: float, months: int) -> list[dict]:
    """Month-by-month schedule. The last instalment is adjusted so balance ends at exactly 0."""
    emi = calculate_emi(principal, annual_rate, months)
    r = monthly_rate(annual_rate)
    balance = float(principal)
    rows: list[dict] = []
    cumulative_interest = 0.0
    for month in range(1, months + 1):
        interest = round(balance * r, 2)
        principal_paid = round(emi - interest, 2)
        payment = emi
        if month == months:                       # clear rounding drift
            principal_paid = round(balance, 2)
            payment = round(principal_paid + interest, 2)
        balance = round(balance - principal_paid, 2)
        if abs(balance) < 0.005:
            balance = 0.0
        cumulative_interest = round(cumulative_interest + interest, 2)
        rows.append({
            "month": month,
            "payment": payment,
            "principal_paid": principal_paid,
            "interest": interest,
            "balance": balance,
            "cumulative_interest": cumulative_interest,
        })
    return rows
