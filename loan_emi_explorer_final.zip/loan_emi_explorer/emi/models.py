"""Data structures: LoanRecord dataclass and date helpers."""
from __future__ import annotations

import calendar
from dataclasses import asdict, dataclass, field
from datetime import date

from .calculator import calculate_emi


def add_months(d: date, months: int) -> date:
    index = d.month - 1 + months
    year, month = d.year + index // 12, index % 12 + 1
    return date(year, month, min(d.day, calendar.monthrange(year, month)[1]))


@dataclass
class LoanRecord:
    id: int
    borrower: str
    loan_type: str
    principal: float
    annual_rate: float
    tenure_months: int
    monthly_income: float = 0.0
    start_date: str = ""
    status: str = "Active"
    notes: str = ""
    # derived - always recomputed from the inputs above, never trusted from disk
    emi: float = field(init=False, default=0.0)
    total_payment: float = field(init=False, default=0.0)
    total_interest: float = field(init=False, default=0.0)

    def __post_init__(self) -> None:
        if not self.start_date:
            self.start_date = date.today().isoformat()
        self.recalculate()

    def recalculate(self) -> None:
        self.emi = calculate_emi(self.principal, self.annual_rate, self.tenure_months)
        self.total_payment = round(self.emi * self.tenure_months, 2)
        self.total_interest = round(self.total_payment - self.principal, 2)

    @property
    def start(self) -> date:
        return date.fromisoformat(self.start_date)

    @property
    def end_date(self) -> date:
        return add_months(self.start, self.tenure_months)

    def is_past_maturity(self, today: date | None = None) -> bool:
        return self.end_date < (today or date.today())

    @property
    def emi_income_ratio(self) -> float | None:
        return self.emi / self.monthly_income if self.monthly_income > 0 else None

    @property
    def duplicate_key(self) -> tuple:
        return (self.borrower.lower(), self.loan_type, round(self.principal, 2),
                round(self.annual_rate, 4), self.tenure_months, self.start_date)

    def to_dict(self) -> dict:
        return asdict(self)
