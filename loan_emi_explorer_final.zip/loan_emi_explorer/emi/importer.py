"""Bulk CSV import with automatic format validation and a detailed row-by-row error log."""
from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from . import config
from .models import LoanRecord
from .validation import ValidationError, build_record

ALIASES = {
    "borrower": ["borrower", "name", "borrower_name", "customer", "customer_name", "applicant"],
    "loan_type": ["loan_type", "type", "category", "loan_category"],
    "principal": ["principal", "amount", "loan_amount", "principal_amount", "loan"],
    "annual_rate": ["annual_rate", "rate", "interest_rate", "rate_pct", "interest", "roi", "annual_interest_rate"],
    "tenure_months": ["tenure_months", "tenure", "months", "term_months", "term"],
    "tenure_years": ["tenure_years", "years", "term_years"],
    "monthly_income": ["monthly_income", "income", "salary"],
    "start_date": ["start_date", "date", "disbursed_on", "start", "disbursement_date"],
    "status": ["status", "state"],
    "notes": ["notes", "note", "remarks", "comment", "comments"],
}
REQUIRED = ["borrower", "loan_type", "principal", "annual_rate"]
IGNORED = {"id", "emi", "total_payment", "total_interest", "end_date", "emi_to_income", "warning_flags"}
TEMPLATE_HEADER = ["borrower", "loan_type", "principal", "annual_rate", "tenure_months", "monthly_income", "start_date", "status", "notes"]


class ImportFormatError(Exception):
    """The file as a whole cannot be imported (missing, empty, wrong columns...)."""


@dataclass
class RowError:
    row: int                 # line number in the file (header = 1)
    messages: list[str]
    raw: str = ""


@dataclass
class ImportResult:
    source: str = ""
    total_rows: int = 0
    valid: list[dict] = field(default_factory=list)      # canonical raw dicts, ready for store.add_many
    errors: list[RowError] = field(default_factory=list)
    ignored_columns: list[str] = field(default_factory=list)

    @property
    def summary(self) -> str:
        return f"{self.total_rows} rows read: {len(self.valid)} valid, {len(self.errors)} rejected"


def _normalise(header: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", (header or "").lower()).strip("_")


def _map_headers(fieldnames: list[str]) -> tuple[dict[str, str], list[str]]:
    lookup = {alias: canon for canon, aliases in ALIASES.items() for alias in aliases}
    mapping: dict[str, str] = {}
    ignored: list[str] = []
    for original in fieldnames:
        norm = _normalise(original)
        canon = lookup.get(norm)
        if canon and canon not in mapping.values():
            mapping[original] = canon
        elif norm not in IGNORED:
            ignored.append(original)
    return mapping, ignored


def parse_csv_text(text: str, existing: list[LoanRecord] | None = None, source: str = "uploaded file") -> ImportResult:
    existing = existing or []
    result = ImportResult(source=source)
    if not text.strip():
        raise ImportFormatError("The file is empty.")
    try:
        sample = text[:4096]
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        reader = csv.DictReader(io.StringIO(text), dialect=dialect)
        if not reader.fieldnames:
            raise ImportFormatError("No header row found.")
        mapping, result.ignored_columns = _map_headers(reader.fieldnames)
    except csv.Error as exc:
        raise ImportFormatError(f"The file is not valid CSV: {exc}") from exc

    present = set(mapping.values())
    missing = [c for c in REQUIRED if c not in present]
    if "tenure_months" not in present and "tenure_years" not in present:
        missing.append("tenure_months (or tenure_years)")
    if missing:
        raise ImportFormatError("Missing required column(s): " + ", ".join(missing) +
                                ". Found: " + ", ".join(reader.fieldnames))

    seen = {r.duplicate_key: f"existing record #{r.id}" for r in existing}
    try:
        for row in reader:
            line = reader.line_num
            result.total_rows += 1
            if None in row:                                     # more cells than headers
                result.errors.append(RowError(line, [f"Too many columns: expected {len(reader.fieldnames)}, found {len(reader.fieldnames) + len(row[None])}."], str(row)))
                continue
            if not any((v or "").strip() for v in row.values()):
                result.total_rows -= 1                           # silently skip blank lines
                continue
            raw = {canon: (row.get(orig) or "").strip() for orig, canon in mapping.items()}
            if raw.get("tenure_years") and not raw.get("tenure_months"):
                raw["tenure_months"] = f"{raw['tenure_years']}y"
            raw.pop("tenure_years", None)
            try:
                record = build_record(raw, record_id=0 if not result.valid else len(result.valid))
            except ValidationError as exc:
                result.errors.append(RowError(line, exc.messages, "; ".join(f"{k}={v}" for k, v in raw.items())))
                continue
            twin = seen.get(record.duplicate_key)
            if twin:
                result.errors.append(RowError(line, [f"Duplicate of {twin} - skipped."], "; ".join(f"{k}={v}" for k, v in raw.items())))
                continue
            seen[record.duplicate_key] = f"row {line}"
            result.valid.append({**raw, "start_date": record.start_date, "loan_type": record.loan_type})
    except csv.Error as exc:
        result.errors.append(RowError(reader.line_num, [f"CSV parsing stopped: {exc}"]))
    return result


def read_text_file(path: Path) -> str:
    try:
        data = Path(path).read_bytes()
    except FileNotFoundError as exc:
        raise ImportFormatError(f"File not found: {path}") from exc
    except OSError as exc:
        raise ImportFormatError(f"Cannot read {path}: {exc}") from exc
    for encoding in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise ImportFormatError("Could not decode the file as text.")


def import_csv_file(path: Path, existing: list[LoanRecord] | None = None) -> ImportResult:
    return parse_csv_text(read_text_file(path), existing, source=config.rel(path))


def error_log_text(result: ImportResult) -> str:
    lines = ["=" * 72, f"{config.APP_NAME} - import error log", f"Source   : {result.source}",
             f"Run at   : {datetime.now():%Y-%m-%d %H:%M:%S}", f"Result   : {result.summary}", "=" * 72, ""]
    if result.ignored_columns:
        lines += [f"Ignored columns: {', '.join(result.ignored_columns)}", ""]
    if not result.errors:
        lines.append("No row errors.")
    for err in result.errors:
        lines.append(f"Row {err.row}:")
        lines += [f"  - {m}" for m in err.messages]
        if err.raw:
            lines.append(f"  data: {err.raw}")
    return "\n".join(lines) + "\n"


def write_error_log(result: ImportResult, folder: Path = config.REPORTS_DIR) -> Path | None:
    if not result.errors:
        return None
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"import_errors_{datetime.now():%Y%m%d_%H%M%S}.txt"
    path.write_text(error_log_text(result), encoding="utf-8")
    return path


def template_csv() -> str:
    return ",".join(TEMPLATE_HEADER) + "\nAsha Verma,Personal,250000,13.5,36,60000,2026-01-15,Active,Sample row\n"
