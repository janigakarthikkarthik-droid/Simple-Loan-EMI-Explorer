"""Threshold warning indicators: overdue deadlines, anomalous entries and critical limit breaches."""
from __future__ import annotations

import statistics
from collections import Counter
from dataclasses import dataclass
from datetime import date

from . import config
from .models import LoanRecord
from .ui_helpers import format_inr

LEVEL_ORDER = {"critical": 0, "warning": 1, "info": 2}


@dataclass
class Alert:
    record_id: int
    borrower: str
    level: str          # critical | warning | info
    code: str
    message: str


def generate_alerts(records: list[LoanRecord], today: date | None = None) -> list[Alert]:
    today = today or date.today()
    alerts: list[Alert] = []

    def add(r: LoanRecord, level: str, code: str, message: str) -> None:
        alerts.append(Alert(r.id, r.borrower, level, code, message))

    by_type: dict[str, list[float]] = {}
    for r in records:
        by_type.setdefault(r.loan_type, []).append(r.principal)
    type_median = {t: statistics.median(v) for t, v in by_type.items() if len(v) >= config.OUTLIER_MIN_RECORDS}
    duplicate_counts = Counter(r.duplicate_key for r in records)

    for r in records:
        # --- overdue deadlines -------------------------------------------------
        if r.status == "Overdue":
            add(r, "critical", "OVERDUE", "Marked Overdue - payment is behind schedule.")
        elif r.status == "Active" and r.is_past_maturity(today):
            add(r, "warning", "PAST_MATURITY",
                f"Tenure ended on {r.end_date.isoformat()} but the loan is still Active - close it or review.")
        elif r.status == "Active" and 0 <= (r.end_date - today).days <= config.ENDING_SOON_DAYS:
            add(r, "info", "ENDING_SOON", f"Final EMI due around {r.end_date.isoformat()} ({(r.end_date - today).days} days).")

        # --- critical limit breaches --------------------------------------------
        ratio = r.emi_income_ratio
        if ratio is not None and ratio > config.EMI_INCOME_CRIT:
            add(r, "critical", "EMI_INCOME", f"EMI is {ratio:.0%} of monthly income (limit {config.EMI_INCOME_CRIT:.0%}).")
        elif ratio is not None and ratio > config.EMI_INCOME_WARN:
            add(r, "warning", "EMI_INCOME", f"EMI is {ratio:.0%} of monthly income (comfort limit {config.EMI_INCOME_WARN:.0%}).")

        if r.annual_rate > config.HIGH_RATE_CRIT:
            add(r, "critical", "HIGH_RATE", f"Interest rate {r.annual_rate:g}% is above {config.HIGH_RATE_CRIT:g}%.")
        elif r.annual_rate > config.HIGH_RATE_WARN:
            add(r, "warning", "HIGH_RATE", f"Interest rate {r.annual_rate:g}% is above {config.HIGH_RATE_WARN:g}%.")

        if r.tenure_months >= config.LONG_TENURE_MONTHS and r.principal > 0:
            add(r, "warning" if r.total_interest >= r.principal else "info", "LONG_TENURE",
                f"Long tenure ({r.tenure_months // 12} years) - total interest is {r.total_interest / r.principal:.0%} of principal.")

        if r.total_interest >= r.principal and r.tenure_months < config.LONG_TENURE_MONTHS:
            add(r, "warning", "INTEREST_HEAVY", f"Interest ({format_inr(r.total_interest, 0)}) exceeds the principal.")

        # --- anomalous entries ----------------------------------------------------
        median = type_median.get(r.loan_type)
        if median and r.principal > config.OUTLIER_MULTIPLE * median:
            add(r, "warning", "OUTLIER", f"Loan amount is {r.principal / median:.1f}x the median {r.loan_type} loan - unusually large.")

        if duplicate_counts[r.duplicate_key] > 1:
            add(r, "warning", "DUPLICATE", "Possible duplicate: another record has identical borrower, type, amount, rate, tenure and date.")

    alerts.sort(key=lambda a: (LEVEL_ORDER[a.level], a.record_id))
    return alerts


def alerts_for(alerts: list[Alert], record_id: int) -> list[Alert]:
    return [a for a in alerts if a.record_id == record_id]


def count_by_level(alerts: list[Alert]) -> dict[str, int]:
    counts = Counter(a.level for a in alerts)
    return {"critical": counts.get("critical", 0), "warning": counts.get("warning", 0), "info": counts.get("info", 0)}
