"""Executive summary: totals, averages, status indicators and key trends."""
from __future__ import annotations

import statistics
from collections import defaultdict
from datetime import date

from . import config
from .alerts import count_by_level, generate_alerts
from .models import LoanRecord
from .ui_helpers import format_inr


def _avg(values) -> float:
    values = list(values)
    return sum(values) / len(values) if values else 0.0


def compute_summary(records: list[LoanRecord], today: date | None = None) -> dict:
    today = today or date.today()
    n = len(records)
    alerts = generate_alerts(records, today)
    out = {
        "count": n, "total_principal": 0.0, "total_interest": 0.0, "total_payable": 0.0,
        "monthly_obligation": 0.0, "avg_principal": 0.0, "avg_rate": 0.0, "weighted_rate": 0.0,
        "avg_tenure": 0.0, "avg_emi": 0.0, "median_principal": 0.0, "interest_ratio": 0.0,
        "highest_emi": None, "lowest_emi": None, "by_type": [], "by_status": [], "trend": [],
        "insights": [], "alert_counts": count_by_level(alerts),
        "health": {"label": "No data", "level": "info", "overdue": 0, "share": 0.0},
    }
    if n == 0:
        return out

    out["total_principal"] = round(sum(r.principal for r in records), 2)
    out["total_interest"] = round(sum(r.total_interest for r in records), 2)
    out["total_payable"] = round(sum(r.total_payment for r in records), 2)
    live = [r for r in records if r.status in ("Active", "Overdue")]
    out["monthly_obligation"] = round(sum(r.emi for r in live), 2)
    out["avg_principal"] = round(_avg(r.principal for r in records), 2)
    out["median_principal"] = round(statistics.median(r.principal for r in records), 2)
    out["avg_rate"] = round(_avg(r.annual_rate for r in records), 2)
    out["weighted_rate"] = round(sum(r.annual_rate * r.principal for r in records) / out["total_principal"], 2)
    out["avg_tenure"] = round(_avg(r.tenure_months for r in records), 1)
    out["avg_emi"] = round(_avg(r.emi for r in records), 2)
    out["interest_ratio"] = out["total_interest"] / out["total_principal"]
    out["highest_emi"] = max(records, key=lambda r: r.emi)
    out["lowest_emi"] = min(records, key=lambda r: r.emi)

    by_type = defaultdict(list)
    by_status = defaultdict(list)
    by_month = defaultdict(list)
    for r in records:
        by_type[r.loan_type].append(r)
        by_status[r.status].append(r)
        by_month[r.start_date[:7]].append(r)

    out["by_type"] = sorted((
        {"type": t, "count": len(rs), "principal": round(sum(r.principal for r in rs), 2),
         "interest": round(sum(r.total_interest for r in rs), 2), "avg_rate": round(_avg(r.annual_rate for r in rs), 2),
         "avg_emi": round(_avg(r.emi for r in rs), 2),
         "share": sum(r.principal for r in rs) / out["total_principal"]} for t, rs in by_type.items()),
        key=lambda d: -d["principal"])
    out["by_status"] = [{"status": s, "count": len(by_status[s]), "principal": round(sum(r.principal for r in by_status[s]), 2)}
                        for s in config.STATUSES if s in by_status]
    out["trend"] = [{"month": m, "count": len(rs), "principal": round(sum(r.principal for r in rs), 2),
                     "avg_rate": round(_avg(r.annual_rate for r in rs), 2)} for m, rs in sorted(by_month.items())]

    overdue = len(by_status.get("Overdue", []))
    share = overdue / n
    if share < 0.05:
        label, level = "Healthy", "ok"
    elif share < 0.15:
        label, level = "Needs watching", "warning"
    else:
        label, level = "At risk", "critical"
    out["health"] = {"label": label, "level": level, "overdue": overdue, "share": share}

    # ---- key trends & insights ------------------------------------------------
    top = out["by_type"][0]
    out["insights"].append(f"{top['type']} loans make up {top['share']:.0%} of all principal ({top['count']} loans).")
    out["insights"].append(f"Interest adds {out['interest_ratio']:.0%} on top of the amount borrowed "
                           f"({format_inr(out['total_interest'], 0)} over the life of all loans).")
    dated = sorted(records, key=lambda r: r.start_date)
    if n >= 6:
        half = n // 2
        older, newer = _avg(r.annual_rate for r in dated[:half]), _avg(r.annual_rate for r in dated[-half:])
        if abs(newer - older) >= 0.25:
            direction = "higher" if newer > older else "lower"
            out["insights"].append(f"Newer loans carry {direction} rates ({newer:.2f}% vs {older:.2f}% on older loans).")
        else:
            out["insights"].append(f"Interest rates are steady across time (about {_avg(r.annual_rate for r in dated):.2f}%).")
    out["insights"].append(f"{len(live)} loans are still running, costing {format_inr(out['monthly_obligation'], 0)} per month in total EMIs.")
    priciest = max(records, key=lambda r: r.annual_rate)
    out["insights"].append(f"Highest rate: {priciest.annual_rate:g}% on #{priciest.id} ({priciest.borrower}).")
    ending = [r for r in records if r.status == "Active" and 0 <= (r.end_date - today).days <= config.ENDING_SOON_DAYS]
    if ending:
        out["insights"].append(f"{len(ending)} active loan(s) will finish within {config.ENDING_SOON_DAYS} days.")
    return out
