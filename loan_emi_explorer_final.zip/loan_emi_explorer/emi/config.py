"""Central configuration: paths, validation limits and warning thresholds."""
import os
from pathlib import Path

APP_NAME = "Simple Loan EMI Explorer"
CURRENCY = "₹"

BASE_DIR = Path(__file__).resolve().parent.parent
# LOAN_EMI_HOME lets tests (or a second user) keep data/ and reports/ somewhere else
HOME_DIR = Path(os.environ.get("LOAN_EMI_HOME", BASE_DIR)).resolve()
DATA_DIR = HOME_DIR / "data"
REPORTS_DIR = HOME_DIR / "reports"
CHARTS_DIR = REPORTS_DIR / "charts"

JSON_FILE = DATA_DIR / "loans.json"
CSV_FILE = DATA_DIR / "loans.csv"
AUDIT_FILE = DATA_DIR / "audit_log.txt"
LEGACY_SAMPLE_CSV = DATA_DIR / "legacy_loans_import.csv"

SCHEMA_VERSION = 1

# ---- Validation limits ------------------------------------------------------
MIN_PRINCIPAL = 1_000.0
MAX_PRINCIPAL = 100_000_000.0          # 10 crore
MIN_RATE = 0.0
MAX_RATE = 40.0                        # % per year
MIN_TENURE = 1                         # months
MAX_TENURE = 360                       # months (30 years)
MAX_INCOME = 100_000_000.0
MIN_DATE_YEAR = 2000
MAX_FUTURE_DAYS = 365                  # start date may be at most a year ahead

LOAN_TYPES = ["Home", "Car", "Personal", "Education", "Business", "Gold"]
STATUSES = ["Active", "Pending", "Closed", "Overdue"]

# ---- Threshold warning rules ------------------------------------------------
EMI_INCOME_WARN = 0.40                 # EMI above 40% of monthly income
EMI_INCOME_CRIT = 0.50                 # ... above 50% is critical
HIGH_RATE_WARN = 20.0                  # % per year
HIGH_RATE_CRIT = 30.0
LONG_TENURE_MONTHS = 240               # 20 years
ENDING_SOON_DAYS = 90
OUTLIER_MULTIPLE = 3.0                 # principal > 3 x the median of its loan type is anomalous
OUTLIER_MIN_RECORDS = 4                # loans of a type needed before its median is meaningful

# ---- Terminal table paging --------------------------------------------------
PAGE_SIZE = 12


def rel(path) -> str:
    """Path shown to the user, relative to the project home when possible."""
    try:
        return str(Path(path).resolve().relative_to(HOME_DIR))
    except ValueError:
        return str(path)
