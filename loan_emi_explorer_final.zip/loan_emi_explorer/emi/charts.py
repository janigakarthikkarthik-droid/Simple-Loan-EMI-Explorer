"""Matplotlib charts. Every function returns a Figure (no pyplot global state), so the same
code serves PNG exports from the terminal app and live display inside the Streamlit GUI."""
from __future__ import annotations

import io
from collections import defaultdict
from pathlib import Path

from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter

from . import config
from .calculator import amortization_schedule, calculate_emi
from .models import LoanRecord
from .ui_helpers import short_inr

INK, TEAL, AMBER, CORAL, SLATE, MIST = "#14262B", "#0F5257", "#F2A541", "#C8553D", "#6B7C85", "#DCE5E8"
PALETTE = [TEAL, AMBER, CORAL, "#3E7CB1", "#7A9E7E", "#8E6C8A"]
STATUS_COLORS = {"Active": TEAL, "Pending": AMBER, "Closed": SLATE, "Overdue": CORAL}

_money_axis = FuncFormatter(lambda v, _pos: f"{config.CURRENCY}{short_inr(v)}")


def _style(ax, title: str, ylabel: str = "", xlabel: str = "") -> None:
    ax.set_title(title, loc="left", fontsize=11, fontweight="bold", color=INK, pad=10)
    ax.set_ylabel(ylabel, color=SLATE, fontsize=9)
    ax.set_xlabel(xlabel, color=SLATE, fontsize=9)
    ax.tick_params(colors=SLATE, labelsize=8)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(MIST)
    ax.grid(axis="y", color=MIST, linewidth=0.7)
    ax.set_axisbelow(True)


def _empty(ax, title: str, message: str = "No data yet - add a loan to see this chart.") -> None:
    _style(ax, title)
    ax.set_xticks([]); ax.set_yticks([])
    ax.grid(False)
    ax.text(0.5, 0.5, message, ha="center", va="center", color=SLATE, fontsize=10, transform=ax.transAxes)


def _new(size=(6.4, 3.8)):
    fig = Figure(figsize=size, dpi=110, facecolor="white", layout="constrained")
    return fig, fig.subplots()


def _group(records, key):
    groups = defaultdict(list)
    for r in records:
        groups[key(r)].append(r)
    return groups


# ------------------------------------------------------------------ single charts
def draw_emi_by_type(ax, records: list[LoanRecord]) -> None:
    title = "Average EMI by loan type"
    if not records:
        return _empty(ax, title)
    groups = _group(records, lambda r: r.loan_type)
    labels = [t for t in config.LOAN_TYPES if t in groups]
    values = [sum(r.emi for r in groups[t]) / len(groups[t]) for t in labels]
    bars = ax.bar(labels, values, color=[PALETTE[i % len(PALETTE)] for i in range(len(labels))], width=0.62)
    for bar, value in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, value, f"{config.CURRENCY}{short_inr(value)}", ha="center", va="bottom", fontsize=8, color=INK)
    ax.yaxis.set_major_formatter(_money_axis)
    _style(ax, title, "Monthly EMI")


def draw_principal_vs_interest(ax, records: list[LoanRecord]) -> None:
    title = "Principal vs interest by loan type"
    if not records:
        return _empty(ax, title)
    groups = _group(records, lambda r: r.loan_type)
    labels = [t for t in config.LOAN_TYPES if t in groups]
    principal = [sum(r.principal for r in groups[t]) for t in labels]
    interest = [sum(r.total_interest for r in groups[t]) for t in labels]
    ax.bar(labels, principal, color=TEAL, width=0.62, label="Principal")
    ax.bar(labels, interest, bottom=principal, color=AMBER, width=0.62, label="Interest")
    ax.yaxis.set_major_formatter(_money_axis)
    ax.legend(frameon=False, fontsize=8, loc="upper right")
    _style(ax, title, "Total amount")


def draw_emi_distribution(ax, records: list[LoanRecord]) -> None:
    title = "How EMIs are distributed (log scale)"
    if not records:
        return _empty(ax, title)
    values = sorted(r.emi for r in records)
    lo, hi = values[0], values[-1]
    bins = min(14, max(5, len(values) // 3))
    if hi / lo < 1.01:                                   # all EMIs (almost) identical
        lo, hi = lo * 0.9, hi * 1.1
    edges = [lo * (hi / lo) ** (i / bins) for i in range(bins + 1)]
    ax.hist(values, bins=edges, color=TEAL, edgecolor="white", linewidth=0.8)
    ax.set_xscale("log")
    median = values[len(values) // 2]
    ax.axvline(median, color=CORAL, linewidth=1.4, linestyle="--")
    ax.text(median, ax.get_ylim()[1] * 0.97, f" median {config.CURRENCY}{short_inr(median)}", color=CORAL, fontsize=8, va="top")
    ax.xaxis.set_major_formatter(_money_axis)
    ax.xaxis.set_minor_formatter(FuncFormatter(lambda v, _pos: ""))
    _style(ax, title, "Number of loans", "Monthly EMI")


def _month_range(first: str, last: str) -> list[str]:
    year, month = int(first[:4]), int(first[5:7])
    end_year, end_month = int(last[:4]), int(last[5:7])
    months = []
    while (year, month) <= (end_year, end_month):
        months.append(f"{year:04d}-{month:02d}")
        year, month = (year + 1, 1) if month == 12 else (year, month + 1)
    return months


def draw_trend(ax, records: list[LoanRecord]) -> None:
    title = "Lending trend by start month"
    if not records:
        return _empty(ax, title)
    groups = _group(records, lambda r: r.start_date[:7])
    months = _month_range(min(groups), max(groups))          # include empty months so the time axis is honest
    principal = [sum(r.principal for r in groups.get(m, [])) for m in months]
    rates = [sum(r.annual_rate for r in groups[m]) / len(groups[m]) if m in groups else float("nan") for m in months]
    xs = list(range(len(months)))
    ax.bar(xs, principal, color=TEAL, width=0.75, alpha=0.9, label="Principal lent")
    ax.yaxis.set_major_formatter(_money_axis)
    step = max(1, len(months) // 8)
    ax.set_xticks(xs[::step])
    ax.set_xticklabels([months[i] for i in range(0, len(months), step)], rotation=40, ha="right")
    twin = ax.twinx()
    twin.plot(xs, rates, color=AMBER, linewidth=1.2, marker="o", markersize=4, label="Average rate (months with loans)")
    twin.set_ylabel("Average rate %", color=SLATE, fontsize=9)
    twin.set_ylim(bottom=0)
    twin.tick_params(colors=SLATE, labelsize=8)
    twin.spines["top"].set_visible(False)
    twin.spines["right"].set_color(MIST)
    _style(ax, title, "Principal lent")
    handles = ax.get_legend_handles_labels()[0] + twin.get_legend_handles_labels()[0]
    labels = ax.get_legend_handles_labels()[1] + twin.get_legend_handles_labels()[1]
    ax.legend(handles, labels, frameon=False, fontsize=8, loc="upper left")


def draw_status_mix(ax, records: list[LoanRecord]) -> None:
    title = "Loans by status"
    if not records:
        return _empty(ax, title)
    groups = _group(records, lambda r: r.status)
    labels = [s for s in config.STATUSES if s in groups]
    counts = [len(groups[s]) for s in labels]
    bars = ax.barh(labels, counts, color=[STATUS_COLORS[s] for s in labels], height=0.55)
    ax.invert_yaxis()
    for bar, count in zip(bars, counts):
        ax.text(bar.get_width(), bar.get_y() + bar.get_height() / 2, f" {count}", va="center", fontsize=9, color=INK)
    ax.set_xlim(0, max(counts) * 1.15)
    _style(ax, title, "", "Number of loans")
    ax.grid(axis="y", visible=False)
    ax.grid(axis="x", color=MIST, linewidth=0.7)


def draw_top_emis(ax, records: list[LoanRecord]) -> None:
    title = "Largest monthly EMIs"
    if not records:
        return _empty(ax, title)
    top = sorted(records, key=lambda r: -r.emi)[:8]
    labels = [f"#{r.id} {r.borrower[:16]}" for r in top]
    ax.barh(labels, [r.emi for r in top], color=[PALETTE[config.LOAN_TYPES.index(r.loan_type) % len(PALETTE)] for r in top], height=0.6)
    ax.invert_yaxis()
    ax.xaxis.set_major_formatter(_money_axis)
    _style(ax, title, "", "Monthly EMI")
    ax.grid(axis="y", visible=False)
    ax.grid(axis="x", color=MIST, linewidth=0.7)


def draw_balance_curve(ax, principal: float, rate: float, months: int, title: str = "Outstanding balance over time") -> None:
    rows = amortization_schedule(principal, rate, months)
    xs = [0] + [r["month"] for r in rows]
    balance = [principal] + [r["balance"] for r in rows]
    cumulative = [0] + [r["cumulative_interest"] for r in rows]
    ax.fill_between(xs, balance, color=TEAL, alpha=0.18)
    ax.plot(xs, balance, color=TEAL, linewidth=2, label="Balance still owed")
    ax.plot(xs, cumulative, color=AMBER, linewidth=2, label="Interest paid so far")
    ax.yaxis.set_major_formatter(_money_axis)
    ax.legend(frameon=False, fontsize=8, loc="upper right")
    _style(ax, title, "", "Months")


CHART_DRAWERS = {
    "emi_by_type": draw_emi_by_type,
    "principal_vs_interest": draw_principal_vs_interest,
    "emi_distribution": draw_emi_distribution,
    "trend": draw_trend,
    "status_mix": draw_status_mix,
    "top_emis": draw_top_emis,
}


def chart(name: str, records: list[LoanRecord]) -> Figure:
    fig, ax = _new()
    CHART_DRAWERS[name](ax, records)
    return fig


def balance_chart(principal: float, rate: float, months: int, title: str = "Outstanding balance over time") -> Figure:
    fig, ax = _new((7.2, 3.8))
    draw_balance_curve(ax, principal, rate, months, title)
    return fig


def record_balance_chart(record: LoanRecord) -> Figure:
    return balance_chart(record.principal, record.annual_rate, record.tenure_months,
                         f"#{record.id} {record.borrower}: balance over {record.tenure_months} months")


def dashboard(records: list[LoanRecord]) -> Figure:
    """Six-panel composite used for the exported report image."""
    fig = Figure(figsize=(16, 9), dpi=100, facecolor="white", layout="constrained")
    axes = fig.subplots(2, 3)
    for ax, name in zip(axes.flat, CHART_DRAWERS):
        CHART_DRAWERS[name](ax, records)
    fig.suptitle(f"{config.APP_NAME} - portfolio dashboard ({len(records)} loans)", fontsize=15, fontweight="bold", color=INK, x=0.01, ha="left")
    return fig


# ---------------------------------------------------------------------- output
def save_figure(fig: Figure, path: Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, format="png", facecolor="white")
    return path


def figure_bytes(fig: Figure) -> bytes:
    buffer = io.BytesIO()
    fig.savefig(buffer, format="png", facecolor="white")
    return buffer.getvalue()
