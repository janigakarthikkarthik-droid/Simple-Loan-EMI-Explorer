"""Keyword and category based filtering."""
from __future__ import annotations

from datetime import date
from typing import Iterable

from .models import LoanRecord

SORT_KEYS = {
    "id": lambda r: r.id,
    "borrower": lambda r: r.borrower.lower(),
    "type": lambda r: r.loan_type,
    "principal": lambda r: r.principal,
    "rate": lambda r: r.annual_rate,
    "tenure": lambda r: r.tenure_months,
    "emi": lambda r: r.emi,
    "interest": lambda r: r.total_interest,
    "start": lambda r: r.start_date,
    "status": lambda r: r.status,
}


def search_records(records: Iterable[LoanRecord], keyword: str | None = None,
                   loan_types: Iterable[str] | None = None, statuses: Iterable[str] | None = None,
                   min_emi: float | None = None, max_emi: float | None = None,
                   min_rate: float | None = None, max_rate: float | None = None,
                   min_tenure: int | None = None, max_tenure: int | None = None,
                   date_from: date | None = None, date_to: date | None = None,
                   sort_by: str = "id", descending: bool = False) -> list[LoanRecord]:
    """Every supplied criterion must match (AND). All words of `keyword` must appear
    in the borrower, type, status, notes or ID."""
    words = (keyword or "").lower().split()
    types = {t.lower() for t in loan_types} if loan_types else None
    stats = {s.lower() for s in statuses} if statuses else None
    out = []
    for r in records:
        if words:
            haystack = f"{r.id} {r.borrower} {r.loan_type} {r.status} {r.notes}".lower()
            if not all(w in haystack for w in words):
                continue
        if types is not None and r.loan_type.lower() not in types:
            continue
        if stats is not None and r.status.lower() not in stats:
            continue
        if min_emi is not None and r.emi < min_emi: continue
        if max_emi is not None and r.emi > max_emi: continue
        if min_rate is not None and r.annual_rate < min_rate: continue
        if max_rate is not None and r.annual_rate > max_rate: continue
        if min_tenure is not None and r.tenure_months < min_tenure: continue
        if max_tenure is not None and r.tenure_months > max_tenure: continue
        if date_from is not None and r.start < date_from: continue
        if date_to is not None and r.start > date_to: continue
        out.append(r)
    out.sort(key=SORT_KEYS.get(sort_by, SORT_KEYS["id"]), reverse=descending)
    return out
