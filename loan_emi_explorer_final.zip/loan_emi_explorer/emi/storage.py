"""Local persistence (JSON primary store + CSV mirror) with corruption recovery and an audit trail."""
from __future__ import annotations

import csv
import json
import os
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Mapping

from . import config
from .models import LoanRecord
from .validation import ValidationError, build_record

CSV_FIELDS = ["id", "borrower", "loan_type", "principal", "annual_rate", "tenure_months", "monthly_income",
              "start_date", "status", "notes", "emi", "total_payment", "total_interest"]


class StorageError(Exception):
    """A file could not be written (permissions, disk full, ...)."""


@dataclass
class LoadReport:
    loaded: int = 0
    skipped: list[str] = field(default_factory=list)
    messages: list[str] = field(default_factory=list)
    recovered: bool = False


def csv_safe(value: Any) -> Any:
    """Neutralise spreadsheet formula injection when writing CSV cells."""
    if isinstance(value, str) and value and value[0] in "=+-@\t\r":
        return "'" + value
    return value


def records_to_csv_rows(records: Iterable[LoanRecord]) -> list[dict]:
    return [{k: csv_safe(v) for k, v in r.to_dict().items() if k in CSV_FIELDS} for r in records]


class LoanStore:
    def __init__(self, json_path: Path = config.JSON_FILE, csv_path: Path = config.CSV_FILE,
                 audit_path: Path = config.AUDIT_FILE):
        self.json_path, self.csv_path, self.audit_path = Path(json_path), Path(csv_path), Path(audit_path)
        self.records: list[LoanRecord] = []

    # ---------------------------------------------------------------- audit trail
    def audit(self, action: str, detail: str = "") -> None:
        try:
            self.audit_path.parent.mkdir(parents=True, exist_ok=True)
            with self.audit_path.open("a", encoding="utf-8") as fh:
                fh.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} | {action:<8} | {detail}\n")
        except OSError:
            pass                                   # auditing must never break the app

    # ----------------------------------------------------------------------- load
    def load(self) -> LoadReport:
        report = LoadReport()
        self.records = []
        try:
            self.json_path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise StorageError(f"Cannot create data folder {self.json_path.parent}: {exc}") from exc

        if not self.json_path.exists():
            self._write_json()
            report.messages.append(f"No data file found - created a fresh one at {self.json_path.name}.")
            self.audit("INIT", "created empty data file")
            return report

        try:
            payload = json.loads(self.json_path.read_text(encoding="utf-8"))
            items = payload["records"] if isinstance(payload, dict) else payload
            if not isinstance(items, list):
                raise ValueError("'records' must be a list")
        except (json.JSONDecodeError, UnicodeDecodeError, KeyError, ValueError, TypeError, OSError) as exc:
            backup = self.json_path.with_name(f"{self.json_path.stem}.corrupt-{datetime.now():%Y%m%d-%H%M%S}.bak")
            try:
                shutil.copy2(self.json_path, backup)
                note = f"A backup of the damaged file was saved as {backup.name}."
            except OSError:
                note = "The damaged file could not be backed up."
            self._write_json()
            report.recovered = True
            report.messages.append(f"Data file was unreadable ({type(exc).__name__}) - started with a clean file. {note}")
            self.audit("RECOVER", f"corrupt data file: {type(exc).__name__}")
            return report

        seen_ids: set[int] = set()
        next_id = 1
        for index, item in enumerate(items, start=1):
            try:
                if not isinstance(item, Mapping):
                    raise ValidationError("record is not an object")
                try:
                    wanted = int(item.get("id", 0))
                except (TypeError, ValueError):
                    wanted = 0
                if wanted <= 0 or wanted in seen_ids:
                    wanted = max([next_id, *seen_ids, 0]) + 1 if seen_ids else next_id
                record = build_record(item, wanted)
            except ValidationError as exc:
                report.skipped.append(f"entry {index}: {exc}")
                continue
            seen_ids.add(record.id)
            next_id = max(next_id, record.id + 1)
            self.records.append(record)
        report.loaded = len(self.records)
        if report.skipped:
            report.messages.append(f"{len(report.skipped)} stored entr{'y was' if len(report.skipped) == 1 else 'ies were'} "
                                   f"skipped because they failed validation.")
        return report

    # ----------------------------------------------------------------------- save
    def _write_json(self) -> None:
        payload = {"schema_version": config.SCHEMA_VERSION, "saved_at": datetime.now().isoformat(timespec="seconds"),
                   "records": [r.to_dict() for r in self.records]}
        tmp = self.json_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.json_path)            # atomic: never leaves a half-written file

    def _write_csv(self) -> None:
        tmp = self.csv_path.with_suffix(".csv.tmp")
        with tmp.open("w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=CSV_FIELDS)
            writer.writeheader()
            writer.writerows(records_to_csv_rows(self.records))
        os.replace(tmp, self.csv_path)

    def save(self) -> None:
        try:
            self._write_json()
            self._write_csv()
        except OSError as exc:
            raise StorageError(f"Could not save data: {exc}") from exc

    # ----------------------------------------------------------------------- CRUD
    def next_id(self) -> int:
        return max((r.id for r in self.records), default=0) + 1

    def get(self, record_id: int) -> LoanRecord | None:
        return next((r for r in self.records if r.id == record_id), None)

    def make_record(self, raw: Mapping[str, Any]) -> LoanRecord:
        return build_record(raw, self.next_id())

    def find_duplicate(self, record: LoanRecord) -> LoanRecord | None:
        return next((r for r in self.records if r.id != record.id and r.duplicate_key == record.duplicate_key), None)

    def add(self, record: LoanRecord) -> LoanRecord:
        self.records.append(record)
        self.save()
        self.audit("ADD", f"#{record.id} {record.borrower} | {record.loan_type} | {record.principal:.2f} "
                          f"@ {record.annual_rate:g}% x {record.tenure_months}m")
        return record

    def add_record(self, raw: Mapping[str, Any]) -> LoanRecord:
        return self.add(self.make_record(raw))

    def add_many(self, raws: Iterable[Mapping[str, Any]]) -> list[LoanRecord]:
        added = []
        for raw in raws:
            record = build_record(raw, self.next_id())
            self.records.append(record)
            added.append(record)
        self.save()
        self.audit("IMPORT", f"{len(added)} records added in bulk")
        return added

    def update(self, record_id: int, raw: Mapping[str, Any]) -> LoanRecord:
        old = self.get(record_id)
        if old is None:
            raise KeyError(f"No record with ID {record_id}")
        new = build_record(raw, record_id)
        self.records[self.records.index(old)] = new
        self.save()
        self.audit("EDIT", f"#{record_id} {new.borrower}")
        return new

    def delete(self, record_id: int) -> LoanRecord:
        old = self.get(record_id)
        if old is None:
            raise KeyError(f"No record with ID {record_id}")
        self.records.remove(old)
        self.save()
        self.audit("DELETE", f"#{record_id} {old.borrower}")
        return old
