"""Terminal presentation helpers: ANSI colour, INR formatting, fixed-width tables, paging."""
from __future__ import annotations

import os
import sys

from .config import CURRENCY, PAGE_SIZE

USE_COLOR = (sys.stdout.isatty() and not os.environ.get("NO_COLOR")) or bool(os.environ.get("FORCE_COLOR"))
if USE_COLOR and os.name == "nt":          # enable ANSI escape codes on Windows consoles
    os.system("")

_CODES = {
    "bold": "1", "dim": "2", "red": "31", "green": "32", "yellow": "33",
    "blue": "34", "magenta": "35", "cyan": "36", "teal": "38;5;30", "amber": "38;5;214",
}


def paint(text: str, *styles: str) -> str:
    if not USE_COLOR or not styles:
        return text
    codes = ";".join(_CODES[s] for s in styles if s in _CODES)
    return f"\033[{codes}m{text}\033[0m"


def bold(t): return paint(t, "bold")
def dim(t): return paint(t, "dim")
def ok(t): return paint(t, "green")
def warn(t): return paint(t, "amber")
def bad(t): return paint(t, "red")


def format_inr(amount: float, decimals: int = 2) -> str:
    """Indian digit grouping, e.g. 12345678.5 -> ₹1,23,45,678.50"""
    negative = amount < 0
    whole, _, frac = f"{abs(amount):.{decimals}f}".partition(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    out = f"{CURRENCY}{whole}" + (f".{frac}" if decimals else "")
    return f"-{out}" if negative else out


def short_inr(amount: float) -> str:
    """Compact axis label: 250000 -> 2.5L, 30000000 -> 3Cr."""
    a = abs(amount)
    for limit, suffix in ((1e7, "Cr"), (1e5, "L"), (1e3, "k")):
        if a >= limit:
            text = f"{amount / limit:.1f}".rstrip("0").rstrip(".")
            return f"{text}{suffix}"
    return f"{amount:.0f}"


def months_text(months: int) -> str:
    years, rem = divmod(months, 12)
    if years and rem:
        return f"{months} mo ({years}y {rem}m)"
    if years:
        return f"{months} mo ({years}y)"
    return f"{months} mo"


def banner(title: str, subtitle: str) -> str:
    width = max(len(title), len(subtitle)) + 8
    top, bottom = "╔" + "═" * width + "╗", "╚" + "═" * width + "╝"
    line1 = "║" + f"  {CURRENCY}  {title}".ljust(width) + "║"
    line2 = "║" + f"     {subtitle}".ljust(width) + "║"
    return paint("\n".join([top, line1, line2, bottom]), "teal", "bold")


def section(title: str) -> None:
    print()
    print(paint(f"── {title} " + "─" * max(4, 62 - len(title)), "teal", "bold"))


def _fit(text: str, width: int, align: str) -> str:
    text = str(text)
    if len(text) > width:
        text = text[: max(1, width - 1)] + "…"
    return text.rjust(width) if align == "r" else text.center(width) if align == "c" else text.ljust(width)


def render_table(headers: list[str], rows: list[list], widths: list[int], aligns: list[str] | None = None) -> str:
    """Fixed-width table. A cell may be 'text' or ('text', 'style') for colour."""
    aligns = aligns or ["l"] * len(headers)
    sep = " │ "
    head = sep.join(_fit(h, w, "c" if a == "r" else a) for h, w, a in zip(headers, widths, aligns))
    rule = "─┼─".join("─" * w for w in widths)
    lines = [paint(head, "bold"), rule]
    for row in rows:
        cells = []
        for cell, w, a in zip(row, widths, aligns):
            text, style = cell if isinstance(cell, tuple) else (cell, None)
            padded = _fit(text, w, a)
            cells.append(paint(padded, style) if style else padded)
        lines.append(sep.join(cells))
    return "\n".join(lines)


def paginate(headers, rows, widths, aligns=None, page_size: int = PAGE_SIZE, empty_msg: str = "No records to show.") -> None:
    """Print a table page by page with next / previous / quit controls."""
    if not rows:
        print(warn(f"  {empty_msg}"))
        return
    pages = max(1, -(-len(rows) // page_size))
    page = 0
    while True:
        chunk = rows[page * page_size:(page + 1) * page_size]
        print(render_table(headers, chunk, widths, aligns))
        print(dim(f"  Showing {page * page_size + 1}-{page * page_size + len(chunk)} of {len(rows)}  (page {page + 1}/{pages})"))
        if pages == 1:
            return
        choice = input("  [n]ext  [p]revious  [q]uit paging: ").strip().lower()
        if choice in ("q", "quit", "x"):
            return
        if choice in ("p", "prev", "previous"):
            page = max(0, page - 1)
        else:                                   # Enter or 'n' -> next, wrapping stops at the end
            if page >= pages - 1:
                return
            page += 1
        print()


def text_bar_chart(items: list[tuple[str, float]], width: int = 32, formatter=lambda v: f"{v:,.0f}") -> str:
    """ASCII fallback used when matplotlib is not installed."""
    if not items:
        return ""
    peak = max(v for _, v in items) or 1
    label_w = max(len(k) for k, _ in items)
    return "\n".join(f"  {k.ljust(label_w)} │{'█' * max(1, int(v / peak * width)) if v else ''} {formatter(v)}" for k, v in items)
