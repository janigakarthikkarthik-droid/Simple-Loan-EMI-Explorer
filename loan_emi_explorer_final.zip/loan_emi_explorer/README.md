# ₹ Simple Loan EMI Explorer

Project #17 · *Everyday Innovators* · Finance & Personal Management

A beginner-friendly Python app that estimates monthly loan payments (EMI) from a loan amount, interest rate and tenure,
validates every input, saves records to local JSON/CSV files, and reports on the whole portfolio with tables, warnings and charts.

It has **two front-ends on one shared backend**:

| Front-end | Start with | Needs |
|---|---|---|
| Terminal menu app (the core deliverable) | `python app.py` | Python 3.10+, `matplotlib` for charts |
| Modern web GUI (stretch feature) | `streamlit run gui_app.py` or `python app.py --gui` | + `streamlit` |

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt    # matplotlib + streamlit
python app.py                      # terminal app
streamlit run gui_app.py           # web GUI (opens in your browser)
```

The project ships with **45 sample loans** already loaded in `data/`, so every screen has something to show on first launch.
Run `python generate_sample_data.py` at any time to reset `data/` to that dataset.

## Feature checklist (mapped to the brief)

**Must-have**

| Requirement | Where it lives |
|---|---|
| Interactive terminal interface | `app.py`: branded welcome screen, 12-option menu, `cancel` at any prompt |
| Defensive input validation | `emi/validation.py`: every field is range-checked; `ask()` loops until the answer is valid; blank, text, negative, out-of-range, impossible dates and spreadsheet-formula names are all caught |
| Core business logic | `emi/calculator.py`: EMI formula (with the 0% edge case), totals, full amortization schedule |
| Local data persistence | `emi/storage.py`: `data/loans.json` (primary) mirrored to `data/loans.csv`; atomic writes; survives restarts |
| Record query & search | `emi/search.py`: keyword (all words must match) + loan type, status, EMI range, sorting |
| Executive summary | `emi/summary.py`: totals, averages, highest/lowest EMI, by type/status/month, health indicator, written insights |
| Visual data plotting | `emi/charts.py`: 6 charts + dashboard + amortization curve, saved as PNG in `reports/charts/` |

**Stretch**

| Feature | Where it lives |
|---|---|
| Multi-format export | `emi/export.py`: Markdown summary, plain-text audit log, standardized CSV report |
| Threshold warning flags | `emi/alerts.py`: overdue, past maturity, ending soon, EMI-to-income, high rate, long tenure, interest-heavy, outlier amount, duplicates |
| GUI enhancement | `gui_app.py`: Streamlit app with dashboard, live calculator, add/edit/delete, search, alerts, import, export |
| Bulk dataset import | `emi/importer.py`: recognises legacy column names, validates row by row, writes `reports/import_errors_*.txt` |

**Challenges from section 8 of the brief**

* *Corrupted or missing storage files*: a missing file is recreated; unreadable or wrongly shaped JSON is copied to `loans.corrupt-<time>.bak` and a clean file is started. Single bad entries are skipped and reported.
* *Invalid or blank terminal input*: handled by the central `ask()` wrapper and the pure `parse_*` functions in `emi/validation.py`.
* *Terminal output that scales*: fixed-width tables with column separators and `[n]ext / [p]revious / [q]uit` paging.
* *Optional dependencies*: if matplotlib is missing, the charts menu falls back to text bar charts instead of crashing; if Streamlit is missing, the GUI option explains how to install it.

## Inputs the app understands

| Field | Accepted | Limits |
|---|---|---|
| Loan amount | `500000`, `5,00,000`, `₹5,00,000`, `5 lakh`, `2cr`, `750k` | ₹1,000 to ₹10,00,00,000 |
| Interest rate | `8.5`, `8.5%` | 0 to 40 % per year |
| Tenure | `60`, `60m`, `18 months`, `5y`, `2.5 years` (plain numbers are months) | 1 to 360 months |
| Start date | `2026-03-15`, `15/03/2026`, `15-03-2026` | 2000 up to one year ahead |
| Status | Active, Pending, Closed, Overdue | |
| Loan type | Home, Car, Personal, Education, Business, Gold (name, prefix or number) | |

All limits and warning thresholds are plain constants in `emi/config.py`.

## Suggested 5-minute demo (matches section 9 of the brief)

1. `python app.py`: show the branded welcome screen and menu.
2. **Option 2, Add loan record**: type deliberately wrong answers (`abc`, `-300000`, rate `50`, tenure `400`, date `31-02-2026`) and show each one being caught and re-asked. Then enter valid values and show the saved record card with its warnings.
3. **Option 7, Executive summary**, then **8, Threshold warnings**, then **9, Charts** (choose 1 for the dashboard).
4. Quit, relaunch, run **option 4** and search for the borrower you just added: the data survived.
5. **Option 11, Bulk import** with the default file `data/legacy_loans_import.csv`: 8 valid rows imported, 11 rejected with row-by-row reasons.
6. **Option 10, Export** (choose 4) and open `reports/`.
7. Finish with `streamlit run gui_app.py` and click through Dashboard, EMI Calculator and Alerts.

Sample outputs are already in `reports/` so you can see the result before running anything.

## Project layout

```
app.py                    terminal app (entry point)
gui_app.py                Streamlit GUI
generate_sample_data.py   rebuilds the demo datasets
emi/
  config.py               paths, limits, thresholds
  models.py               LoanRecord dataclass
  calculator.py           EMI + amortization
  validation.py           parsers, build_record, ask()/confirm()
  storage.py              JSON/CSV persistence, recovery, audit trail
  search.py  summary.py  alerts.py  export.py  importer.py  charts.py  ui_helpers.py
data/                     loans.json, loans.csv, sample_loans.*, legacy_loans_import.csv
reports/                  exported reports, import error logs, charts/
tests/                    53 unit and end-to-end tests
.streamlit/config.toml    GUI theme
```

## Tests

```bash
python -m unittest discover -s tests -t .
```

The suite covers EMI maths (checked against known values), every validator, storage recovery and restart persistence, search, alerts,
summary, import/export, all charts, a scripted terminal session with bad input, and a stubbed run of every GUI page.
Tests always use a temporary copy of `data/` and `reports/`.

## Notes

* Currency is shown with Indian digit grouping (₹12,34,567.00). Change `CURRENCY` in `emi/config.py` for another symbol.
* `data/audit_log.txt` records every add, edit, delete, import, export and chart run; the audit-log export includes its latest entries.
* Set `LOAN_EMI_HOME=/some/folder` to keep `data/` and `reports/` somewhere else.
* Set `NO_COLOR=1` to turn off terminal colours.
